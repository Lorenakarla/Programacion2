///Las matrices son vector de vectores
#include <stdio.h>
#include <stdlib.h>
#define FIL 3
#define COL 2

void cargar_matriz();
void mostrar_matriz(int mat[][COL]);
int main()
{
    int mat[][COL]={{1,2},
                    {3,4},
                    {5,6}
    };
    printf("\n%p\n",mat);
    ///DEFINICION: las matrices son un array bidimensional

/*     es decir, se puede ver como un vector que contiene otros vectores internos(filas)
 *     mat-> FA00
 *     *mat->mat[0]->FA00
 *     **mat->*mat[0]->mat[0][0]->1
 */
    ///COMO MOSTRAR MAT
    mostrar_matriz(mat);

    ///QUE HACE?
//    mat++;
/*    me muestra la primera posicion de la siguiente fila*/

    printf("\n%p", mat+ 1);

    ///SI UTILIZO UNICAMENTE UNA PARTE DE LA MATRIZ ENTONCES
/*    si tengo una matriz que sea de 5X6 y solo utilizo solo 3X3
*   el prototipo seria:
*   void imp_mat(const int mat[][COL, int cc]);
*   cc= cantidad de elementos
*/
    return 0;
}
//void cargar_matriz()
//{
//    int mat1[FIL][COL];
//    int mat2[FIL][COL]={{1,2},{3,4},{5,6} };
//    int mat3[FIL][COL]={ {1},{3,4}};
//    int mat4[FIL][COL]={ {1,2}, {3} };
//    int mat5[][COL]={ {1},{3} };
//    int mat6[][COL]={ {1,2}, {3,4,5} };///el 5 no lo pone porque esta fuera de la dimension 3X2
//
//    ///siempre definir las columnas
//    ///cuenta que hace el compi mat + i * col + j
//}

void mostrar_matriz(int mat[][COL])
{
    int i,j;

    for(i=0; i<FIL; i++)
    {
        for(j=0;j<COL;j++)
            printf("%d",mat[i][j]);

        printf("\n");
    }
}
