#include <stdio.h>
#include <stdlib.h>
#define aMayus(x) ((x)>='a' && (x)<='z')?(x)-32: (x)
#define aMinus(x) ((x)>='A' && (x)<='Z')?(x)+32: (x)
#define esBlanco(x) ((x)==' ' || (x)=='\t' || (x)==',')?1:0
#define esComa(x) ((x)==',') ? 1:0

char* normalizar(char *s);
int encuentra_coma(char *s);

int main()
{
    char cadena[]="  ,, goMEZ  ,  JoSE  , cARLos   ";
//    char cadena[]=" ";
    printf("\n[%s]\n",cadena);
    printf("\nLa cadena normalizada es: ");
    printf("\n[%s]", normalizar(cadena));

    return 0;
}

char* normalizar(char *s)
{
    char *lee=s;
    char *escribe=s;
    int cont=0;

    if(*s)
    {
        while(*lee)
        {
            ///mientras haya blancos incremento
            while(esBlanco(*lee))
                lee++;

            ///encontro algo, hago el intercambio
            *escribe=aMayus(*lee);
            escribe++;
            lee++;


            ///transformo lo que queda de la palabra
            while(*lee && !esBlanco(*lee))
            {
                *escribe=aMinus(*lee);
                lee++;
                escribe++;
            }

            ///encontro un blanco
            *escribe=' ';
            escribe++;

            if(esBlanco(*(lee-1)) && esBlanco(*escribe))
            {
                *escribe='\0';
            }

        }
        cont++;
    }

    return s;
}
