///hacer primero ITOA luego ATOI
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int valor=123;
    printf("Hello world!\n");
    return 0;
}
