#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#define SOCIOA "socioa.dat"
#define SOCIAB "sociob.dat"
#define TODO_OK 1
#define TODO_MAL 0

typedef struct
{
    int d,
    m,
    a;
}t_fecha;


#endif // MAIN_H_INCLUDED
