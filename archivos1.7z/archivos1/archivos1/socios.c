#include "main.h"
#include "socios.h"

FILE* generar_lote_socios_a()
{
    FILE *pa;
    t_socio socio_a;

    pa=fopen(SOCIOA, "wb");

    if(!pa)
    {
        printf("\nError al crear el archivo de SOCIOS A\n");
        exit(1);
    }

    t_socio sa[]=
    {
        {70,12345675,"Patrick Rothfuss",{23,11,2012}},
        {68,12345679,"Gabriel Garcia Marquez",{12,07,1991}},
        {69,12345680,"Christopher Paolini", {30,05,2017}},
    };

    fwrite(sa, sizeof(sa),1, pa);

    fclose(pa);
    //////////////////////////////////////////////////////////////////////////////////////

    pa=fopen(SOCIOA, "rb");

    if(!pa)
    {
        printf("\nError al abir el archivo SOCIA A en modo lectura\n");
        exit(2);
    }

    fread(&socio_a,sizeof(t_socio),1, pa);

    while(!feof(pa))
    {
        printf("\n%d %d %s \t%d/%d/%d\n",socio_a.nro_socio,
               socio_a.dni,
               socio_a.apyn,
               socio_a.f_ing.d, socio_a.f_ing.m, socio_a.f_ing.a);
        fread(&socio_a,sizeof(t_socio),1,pa);
    }

    fclose(pa);
    return pa;
}
FILE * generar_lote_socios_b()
{
    FILE *pb;
    t_socio socio_b;

    if ( !(pb=fopen(SOCIAB, "wb")))
    {
        printf("\nError al crear el archivo SOCIO B\n");
        exit(1);
    }

    t_socio sb[]=
    {

        {70,12345675,"Patrick Rothfuss",{23,11,2012}},
        {63,12345676,"Emily Bronte", {30,05,2005}},
        {62,12345677,"Sir Conan Doyle",{05,01,1999}},
        {61,12345678,"Julio Cortazar",{19,02,1997}}
    };

    fwrite(sb,sizeof(sb),1,pb);
    fclose(pb);

    if(!(pb=fopen(SOCIAB,"rb")))
    {
        printf("\nError leyendo el archivo de SOCIOS B\n");
        exit(2);
    }

    fread(&socio_b,sizeof(t_socio),1,pb);

    while(!feof(pb))
    {
        printf("\n%d %d %s \t%d/%d/%d\n",socio_b.nro_socio,
               socio_b.dni,
               socio_b.apyn,
               socio_b.f_ing.d, socio_b.f_ing.m, socio_b.f_ing.a);
        fread(&socio_b,sizeof(t_socio),1,pb);
    }
    fclose(pb);

    return pb;
}
int abrir_archivo(FILE **pf, const char *nombre, const char *modo, int msj)
{
    *pf=fopen(nombre,modo);

    if(!*pf)
    {
        printf("\nError abriendo el archivo %s en modo %s",nombre, modo);
        return TODO_MAL;

    }
    else
    {
        if(msj)
            printf("\nNOTA: El archivo %s se abrio correctamente en modo %s\n",nombre,modo);

        return TODO_OK;
    }
}

void mostrar_archivo()
{
    FILE *pf;
    t_socio s;

//    abrir_archivo(&pf,"fusionsocios.dat","rb",1);

    pf=fopen("fusionsocios.dat", "rb");
    if(!pf)
    {
        printf("\nError abriendo el archivo fusionsocios.dat\n");
        return;
    }

    fread(&s,sizeof(t_socio),1,pf);

    while(!feof(pf))
    {
        printf("\n%d %d %s \t%d/%d/%d\n",s.nro_socio,
                                           s.dni,
                                           s.apyn,
                                           s.f_ing.d, s.f_ing.m, s.f_ing.a);

        fread(&s, sizeof(t_socio),1,pf);
    }

    fclose(pf);
}

int union_archivos(FILE *pa, FILE *pb)
{
    FILE *pf;
    t_socio socioa;
    t_socio sociob;
    t_socio fusion;

    /**Preparo el archivo nuevo*/
    abrir_archivo(&pf,"fusionsocios.dat", "wb",0);

    /**Empiezo a leer los archivosa fusionar*/

    fread(&socioa,sizeof(t_socio),1,pa);
    fread(&sociob,sizeof(t_socio),1,pb);

    while(!feof(pa) && !feof(pb))
    {
        if(socioa.dni > sociob.dni)
        {
            fwrite(&fusion,sizeof(t_socio),1,pf);
            fread(&sociob,sizeof(t_socio),1,pb);
        }
        else if(socioa.dni < sociob.dni)
        {
            fwrite(&fusion,sizeof(t_socio),1,pf);
            fread(&socioa,sizeof(t_socio),1,pa);

        }
        else
        {
            fwrite(&fusion,sizeof(t_socio),1,pf);
            fread(&socioa, sizeof(t_socio),1,pa);
            fread(&sociob,sizeof(t_socio),1,pb);
        }
    }

    while(!feof(pa))
    {
        fwrite(&fusion,sizeof(t_socio),1,pf);
        fread(&socioa,sizeof(t_socio),1,pa);
    }

    while(!feof(pb))
    {
        fwrite(&fusion,sizeof(t_socio),1,pf);
        fread(&sociob,sizeof(t_socio),1,pb);
    }

    fclose(pa);
    fclose(pb);
    fclose(pf);
//////////////////////////////////////////////
    mostrar_archivo();

    return 1;
}























