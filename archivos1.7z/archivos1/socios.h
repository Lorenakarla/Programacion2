#ifndef SOCIOS_H_INCLUDED
#define SOCIOS_H_INCLUDED
#include "main.h"

typedef struct
{
    int nro_socio;
    int dni;
    char apyn[30];
    t_fecha f_ing;

}t_socio;

//int abrir_archivo(FILE **, const char nombre, const char modo, int consin_msj)
int abrir_archivo(FILE **, const char *nombre, const char *modo, int msj);
FILE * generar_lote_socios_a();
FILE * generar_lote_socios_b();
int union_archivos(FILE *pa, FILE *pb);
int comparar_dni(t_socio *d1,t_socio *d2);
//void mostrar_archivo(const void *dato);
void mostrar_archivo();
void actualizar_nro_socio(t_socio *, FILE *);

#endif // SOCIOS_H_INCLUDED
