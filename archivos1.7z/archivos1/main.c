/**Repaso como crear archivo binario y de texto*/
#include "main.h"
#include "socios.h"

int main()
{
    FILE *pa=NULL;
    FILE *pb=NULL;

    /**********************************************************************/
    printf("\n");
    printf("************ARCHIVO SOCIOS A*****************\n");
    pa=generar_lote_socios_a();
    printf("\n");
    /**********************************************************************/
    printf("\n");
    printf("************ARCHIVO SOCIOS B*****************\n");
    pb=generar_lote_socios_b();
    printf("\n");
    /**********************************************************************/

    /**< Fusionar dos archivos con datos maestros en un tercer archivo. Los archivos estan  ordenados por
    DNI*/
    abrir_archivo(&pa,"socioa.dat", "rb",0);
    abrir_archivo(&pb,"sociob.dat","rb",0);

   printf("\n");
    printf("************ARCHIVO SOCIOS B*****************\n");

    if(union_archivos(pa,pb))
        printf("\nSe fusionaron correctamente los archivos\n");
    else
        printf("\nError al fusionar los archivos\n");

    /**********************************************************************/


//    mostrar_archivo();

    return 0;
}
