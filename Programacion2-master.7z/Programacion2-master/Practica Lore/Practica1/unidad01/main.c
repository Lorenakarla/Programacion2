#include "../../Biblioteca/matematica.h"
#include "../../Biblioteca/menu.h"
int main()
{
    int opcion=0;
    printf("**************************************************\n");
    printf("\n\tMenu principal Unidad 1\n\n");
    printf("**************************************************\n");
    mostrar_opciones();
    menu(opcion);

    return 0;
}
