#include "matematica.h"
#include "menu.h"

double factorial(int n)
{
    int r=1,cont=1;

    while(cont <=n)
    {
        r*=cont;
        cont++;
    }
    return r;
}

void combinatorio(int m, int n)
{
    double resultado, numerador, denominador;

    if(m>=n && n>=0)
    {
        numerador=factorial(m);
        denominador=factorial(n)*factorial(m-n);
        resultado=numerador/denominador;
    }


    printf("\nEl combinatorio de %d y %d es: %lf", m,n, resultado);
}
