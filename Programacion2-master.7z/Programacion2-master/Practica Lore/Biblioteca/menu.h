#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void mostrar_opciones();
void menu();
void submenu(int opcion);

void menu_matematica();
void menu_matrices();
void menu_vectores();
void menu_fechas();


#endif // MENU_H_INCLUDED
