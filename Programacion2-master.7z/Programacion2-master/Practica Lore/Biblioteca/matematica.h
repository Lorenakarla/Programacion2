#ifndef MATEMATICA_H_INCLUDED
#define MATEMATICA_H_INCLUDED

double factorial(int n);
void combinatorio(int n, int m);
void e_a_la_X();


#endif // MATEMATICA_H_INCLUDED
