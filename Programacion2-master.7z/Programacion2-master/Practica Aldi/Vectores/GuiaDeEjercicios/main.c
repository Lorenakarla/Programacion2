#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("\nGuia de ejercicios completos\n");
    printf("\n----------------------------\n");
    printf("\n1. Ejercicios matematicos\n");
    printf("2. Ejercicios de vectores\n");
    return 0;
}
