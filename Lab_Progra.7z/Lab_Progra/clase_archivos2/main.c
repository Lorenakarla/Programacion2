//Actualizacion de archivos--MERGE--
#include <stdio.h>
#include <stdlib.h>
#define SOCIA "socioa.dat"
#define SOCIOB "sociob.dat"

///Dos archivos tienen = CLAVE y esta ORDENADO----> es MERGE
///ejercicio de club- socios a y socios b

typedef struct
{
    int d, m,a;
} t_fecha;

typedef struct
{
    int dni;
    char apyn[30];
    t_fecha f_ing;
} t_socio;

FILE * generar_lote_socio_a();
FILE * generar_lote_socio_b();

void actualizar_socios(FILE *, FILE *);

int main()
{
    FILE *pa;
    FILE *pb;


    printf("\nLote de SOCIOS A\n");
    pa=generar_lote_socio_a();
    printf("\n");
    printf("\nLote de SOCIOS B\n");
    pb=generar_lote_socio_b();
    printf("\nActualizando los archivos...\n");
    actualizar_socios(pa, pb);

    return 0;
}
FILE * generar_lote_socio_a()
{
    t_socio socio_a[]=
    {
        {12345678,"Julio Cortazar",{19,02,1997}},
        {12345677,"Sir Conan Doyle",{05,01,1999}},
        {12345676,"Emily Bronte", {30,05,2005}},
        {12345675,"Patrick Rothfuss",{23,11,2012}}
    };
    FILE *pa;
    t_socio soc_a;

    ///creo el archivo- utilizo la variable estructura de socio

    if(! (pa=fopen(SOCIA, "wb+")))
    {
        printf("\nError creando el archivo de socios A\n");
        exit(1);
    }

    fwrite(&socio_a,sizeof(socio_a),1,pa);

    fclose(pa);

    ///leo el archivo- utilizo la variable del tipo socio a

    if(! (pa=fopen(SOCIA, "rb")))
    {
        printf("\nError leyendo el archivo de socios A\n");
        exit(2);
    }

    fread(&soc_a,sizeof(t_socio),1,pa);

    while(!feof(pa))
    {
        printf("\n%d %s %d/%d/%d",
               soc_a.dni, soc_a.apyn, soc_a.f_ing.d, soc_a.f_ing.m, soc_a.f_ing.a);
        fread(&soc_a, sizeof(t_socio),1,pa);
    }

    fclose(pa);
    return pa;
}
FILE * generar_lote_socio_b()
{
    t_socio socio_b[]=
    {
        {12345678,"Julio Cortazar",{19,02,1997}},
        {12345679,"Gabriel Garcia Marquez",{12,07,1991}},
        {12345680,"Christopher Paolini", {30,05,2017}},
        {12345675,"Patrick Rothfuss",{23,11,2012}}
    };

    FILE *pb;
    t_socio soc_b;

    if(! (pb=fopen(SOCIOB, "wb+")))
    {
        printf("\nError creando el archivo de socios B\n");
        exit(3);
    }

    fwrite(&socio_b, sizeof(socio_b),1,pb);

    fclose(pb);

    if(! (pb=fopen(SOCIOB, "rb")))
    {
        printf("\nError leyendo el archivo de socios B\n");
        exit(4);
    }

    fread(&soc_b, sizeof(soc_b),1,pb);

    while(!feof(pb))
    {
        printf("\n%d %s %d/%d/%d",
               soc_b.dni, soc_b.apyn, soc_b.f_ing.d, soc_b.f_ing.m, soc_b.f_ing.a);
        fread(&soc_b,sizeof(soc_b),1,pb);
    }

    fclose(pb);
    return pb;
}

void actualizar_socios(FILE *a, FILE *b)
{
    t_socio socio_a;
    t_socio socio_b;


    fread(&socio_a, sizeof(socio_a),1,a);
    fread(&socio_b, sizeof(socio_b),1,b);

    while(!feof(a) && !feof(b))
    {
        if( socio_a.dni < socio_b.dni)
        {
            fread(&socio_a, sizeof(socio_a),1,a);
        }
        else if( socio_a.dni > socio_b.dni)
        {
            fread(&socio_b, sizeof(socio_b),1,b);
        }
        else    ///si son iguales no hago nada, avanzo
        {
            fread(&socio_a, sizeof(socio_a),1,a);
            fread(&socio_b, sizeof(socio_b),1,b);
        }
    }
    while(!feof(a))
        fread(&socio_a, sizeof(socio_a),1,a);


    while(!feof(b))
        fread(&socio_b, sizeof(socio_b),1,b);


    fclose(a);
    fclose(b);
}
