/* Introduccion a archivos, se vio como inicializar un archivo (BIN-TXT)
 * Como pasar de texto a binario
 */
#include <stdio.h>
#include <stdlib.h>
#define ALUMNO "alumnos.dat"
#define EMPLE "esclavos.dat"

typedef struct
{
    int d,m,a;
} t_fecha;

typedef struct
{
    int dni;
    char apyn[30];
    char sexo;
    float promedio;
} t_alu;

typedef struct
{
    int dni;
    char apyn[30];
    float sueldo;
} t_emp;

//void crear_lote_alu();
//void crear_lote_emp();

int main()
{
    FILE *emp;
    FILE *alu;
    t_emp empleados;
    t_alu alumnos;
    int i;

    ///creando un archivo binario alumnos

    if ( !(alu=fopen(ALUMNO,"wb+")))
    {
        printf("\nError creando el archivo de Alumnos\n");
        exit(1);
    }

    ///creando un archivo binario de empleados

    if( ! (emp=fopen(EMPLE,"wb+")))
    {
        printf("\nError creando el archivo de Empleados\n");
        exit(2);
    }

    ///creo estructura con el lote de alumnos a guardar en el archivo
    t_alu estudiantes[]=
    {
        {12345678,"Artemisa",'F', 8.96},
        {12345677, "Apolo", 'M', 8.99},
        {12345676, "Poseidon", 'M', 7.59},
        {12345444, "Afrodita", 'F', 7.99}
    };

    for(i=0; i<4/*sizeof(estudiantes)*/; i++)
    {
        fwrite(estudiantes, sizeof(estudiantes),1, alu);
    }

    fclose(alu);
///////////////////////////////////////////////////////

    if ( !(alu=fopen(ALUMNO,"rb")))
    {
        printf("\nError abriendo el archivo de Alumnos\n");
        exit(1);
    }

    fread(&empleados,sizeof(t_alu),1,alu);

    while(!feof(alu))
    {
        printf("\n%d\t%s\t%c\t%f\n", alumnos.dni, alumnos.apyn,alumnos.sexo, alumnos.promedio);
        fread(&alumnos,sizeof(t_alu),1,alu);
    }
    fclose(alu);

    return 0;
}

