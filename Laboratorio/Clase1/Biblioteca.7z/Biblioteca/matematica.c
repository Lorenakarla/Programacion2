#include "matematica.h"

double factorial(int num)
{
    int res=1, result=1;

    if(num <= 1)
        return 1;
    while(res <= num)
    {
        result*=res;
        res++;
    }
    return result;
}

double combinatorio(int n, int m)
{
    int resta = 0;
    double denominador = 0, numerador = 0, total = 0;

    if  (!(m >=n && n>=0))
        return 0;

    resta = m-n;

    denominador = factorial(n)*factorial(resta);
    numerador = factorial(m);

    total= numerador / denominador;

    return total;
}
