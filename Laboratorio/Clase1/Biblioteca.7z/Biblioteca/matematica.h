#ifndef MATEMATICA_H_INCLUDED
#define MATEMATICA_H_INCLUDED


double factorial(int num);
double combinatorio(int n, int m);

#endif // MATEMATICA_H_INCLUDED
