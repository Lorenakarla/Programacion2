#include <stdio.h>
#include <stdlib.h>
#include "../Biblioteca/matematica.h"
#define Cuadrado(x) ((x)*(x))
#define MAYOR(x,y) ((x)>(y) ? (x):(y) )
//Las macros, a diferencia de las fuciones , son simplemente reemplazos son mas rapidas. Las funciones tienen subrutinas

int main()
{
    int num, n, m;

    printf("Ingrese un numero\n");
    scanf("%d",&num);
    printf("El factorial de un numero es %.2f", factorial(num));
    printf("\n---------------------------------------\n");
    printf("Ingrese n: \n");
    scanf("%d",&n);
    printf("Ingrese m: \n");
    scanf("%d",&m);

    if(! (combinatorio(n,m)))
        printf("\nNo cumple con la formula\n");
        else
        printf("\nEl combiantorio es %lf", combinatorio(n, m));

    printf("\nLa macro es: \n");

//    int r;
    //    r=Cuadrado(5);
//    es lo mismo que arriba
    printf("%d", Cuadrado(5));
    return 0;
}
