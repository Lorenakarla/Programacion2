#include "arbol.h"

void mostrarPersona(const void *d)
{
    tPer *aux= (tPer *)d;

    if(d)
    {
        printf("%-*s %8ld %c\n",
               sizeof(aux->apyn)-1, aux->apyn,
               aux->dni,
               aux->sexo);
    }
    else
    {
        printf("%-*.*s D. N. I. \tSEXO\n",
               sizeof(aux->apyn)-1, sizeof(aux->apyn)-1,
               "Apellido(s), Nombre(s)");
    }
}
//-------------------------------------------------//
void crearArbol(tArbol *pa)
{
    *pa=NULL;
}
int alturaArbol(const tArbol *pa)
{
    if(*pa == NULL)
        return 0;
    int hi=alturaArbol(&(*pa)->izq);
    int hd=alturaArbol(&(*pa)->der);

    return hi>hd ? hi+1 : hd+1;
}
int contarNodos(const tArbol *pa)
{
    if(*pa)
    {
        return contarNodos(&(*pa)->izq)+ contarNodos(&(*pa)->der) + 1;
    }
    return 0;
}
int contarHojas(const tArbol *pa)
{
    if(*pa)
    {
        if((*pa)->izq == (*pa)->der)
            return 1;

    return contarHojas(&(*pa)->izq) + contarHojas(&(*pa)->der);
    }
    return 0;
}
int contarHojasInternas(const tArbol *pa);
int contarHojasExternas(const tArbol *pa);

int mostrarNumeroNodoEInformar(const tArbol *pa, void (*mostrar)(const void *))///se puede agregar un puntero file
{
    if(!*pa)
        return 0;
    return mostrarRecursivo(pa,1, mostrar);
}

int mostrarRecursivo(const tArbol *pa, int num, void (*mostrar)(const void *))
{
    if(*pa)
    {
        ///muestro nodo
        printf("%d ", num);
        ///muestro info
        mostrar((*pa)->info);

        return mostrarRecursivo(&(*pa)->izq,num*2, mostrar) + mostrarRecursivo(&(*pa)->der, (num *2)+1, mostrar);
    }
    return 0;

}
void mostrar_arbol_horizontal(tArbol *pa)
{
    int cant=0;

    mostrar_arbol(pa, cant);
}
void mostrar_arbol(tArbol *pa, int cant)
{
    if(!*pa)
        return;

    mostrar_arbol(&(*pa)->der, cant +1);

    tPer *per= (tPer *)(*pa)->info;
    int i;
    for(i=0; i<cant; i++)
        printf("\t");

//    printf("%d\n",(*pa)->info);
    printf("%ld\n",per->dni);
    mostrar_arbol(&(*pa)->izq, cant + 1);
}

//////////////////////////////////////////////////////////////////////////////////


int esCompletoHastaNivel(const tArbol *pa, int h)
{
    if(!*pa)
        return 0;

    return esCompletoHastaNivel(&(*pa)->izq, h-1) && esCompletoHastaNivel(&(*pa)->der, h-1);
}

int esCompleto(const tArbol *pa)
{
    int h=alturaArbol(pa);

    return esCompletoHastaNivel(pa, h-1);
}
int esBalancead(const tArbol *pa)
{
    int h=alturaArbol(pa);

    return esCompletoHastaNivel(pa, h-2);
}
int esAvl(const tArbol *pa)
{
    if(!*pa)
        return 1;///por convencion decimos que si no hay nodo es avl

    int hi=alturaArbol(&(*pa)->izq);
    int hd=alturaArbol(&(*pa)->der);

    if(  (abs(hi-hd)) > 1)
        return 0;

    return esAvl(&(*pa)->izq)&& esAvl(&(*pa)->der);
}

int contarNodosHastaNivelN(const tArbol *pa, int n)
{
    if(*pa)
    {
        if(n==0)
            return 0;
        return contarNodosHastaNivelN(&(*pa)->izq, n-1) + contarNodosHastaNivelN(&(*pa)->der, n-1)+1;
    }
    return 0;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
int arbolLLeno(const tArbol *pa, unsigned cantBytes)
{
    tNodo *aux=(tNodo *)malloc(sizeof(tNodo));
//    aux->info=malloc(cantBytes);
    void *info=malloc(cantBytes);

//    free(aux->info);
    free(aux);
    free(info);

    return aux==NULL || info==NULL;
}
int arbolVacio(const tArbol *pa);
////////////////////////////////////////////////////////////////////////////////
//void recorerEnOrden(const tArbol *pa)
//{
//    tPer *per= (tPer *)(*pa)->info;
//
//    if(*pa)
//    {
//        recorerEnOrden(&(*pa)->izq);
//        printf("%ld", per->dni);
//        recorerEnOrden(&(*pa)->der);
//    }
//}
void recorerEnOrden(const tArbol *pa, void (*mostrar)(const void *))
{
    if(*pa)
    {
        recorerEnOrden(&(*pa)->izq, mostrar);
        mostrar((*pa)->info);
        recorerEnOrden(&(*pa)->der, mostrar);
    }
}
void recorerEnPostOrden(const tArbol *pa, void (*mostrar)(const void *))
{
    if(*pa)
    {
        recorerEnPostOrden(&(*pa)->izq, mostrar);
        recorerEnPostOrden(&(*pa)->der, mostrar);
        mostrar((*pa)->info);
    }
}
void recorerEnPreOrden(const tArbol *pa);


//////////////////////////

int insertarEnArbolRecursivo(tArbol *pa, const void *d, unsigned tamInfo, int (*comp)(const void *, const void *))
{
    tNodo *nue=(tNodo *)malloc(sizeof(tNodo));
    void *aux=malloc(tamInfo);///es lo mismo que hacer nue->info pero es menos performante
    if(*pa)
    {
        int cmp=comp(d,(*pa)->info);

        if(cmp == 0)
            return 2;///clave duplicada
        if(cmp <0)
            return insertarEnArbolRecursivo(&(*pa)->izq,d, tamInfo,comp);
        else
            return insertarEnArbolRecursivo(&(*pa)->der,d,tamInfo,comp);

    }
    if(nue == NULL || aux == NULL)
    {
        free(nue);
        free(aux);
        return 0;///sin memoria
    }
    nue->info=aux;
    nue->cantBytes=tamInfo;
    nue->izq=NULL;
    nue->der=NULL;

    memcpy(nue->info,d,tamInfo);
    *pa=nue;///apunto al nuevo nodo

    return 1;///todo bien
}
int insertarEnArbol(tArbol *pa, const void *d, unsigned tamInfo, int (*comp)(const void *, const void *))
{
    while(*pa)
    {
        int cmp= comp((*pa)->info, d);

        if(cmp == 0)
            return 2;///clave duplicada

        else if( cmp > 0)
            pa=&(*pa)->izq;
        else
            pa=&(*pa)->der;
    }
    *pa=(tNodo *)malloc(sizeof(tNodo));

    if(!*pa)
        return 0;

    (*pa)->info=malloc(tamInfo);

    if((*pa)->info == NULL)
    {
        free(*pa);
        return 0;///sin memo
    }
    (*pa)->cantBytes=tamInfo;

    memcpy((*pa)->info, d,tamInfo);
    (*pa)->izq=NULL;
    (*pa)->der=NULL;

    return 1;///todo bien

}
void validarTipoDeArbol(const tArbol *pa)
{
    if(esCompleto(pa))
    {
        puts("\nEl arbol es completo\n");
    }
    else
    {
        if(esBalancead(pa))
            puts("\nEl arbol es balanceado\n");
        else
        {
            if(esAvl(pa))
                puts("\nEl arbol es AVL\n");
            else
                puts("\nNo es nada\n");
        }
    }
}
