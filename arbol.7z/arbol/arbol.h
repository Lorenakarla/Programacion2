#ifndef ARBOL_H_INCLUDED
#define ARBOL_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int dni;
}tAlu;

typedef struct
{
    char apyn[31];
    long dni;
    char sexo;
}tPer;

typedef struct sNodo
{
    void * info;
    unsigned cantBytes;
    struct sNodo *izq,
                 *der;
}tNodo, *tArbol;

void cargarArbol();
int arbolLLeno(const tArbol *pa, unsigned cantBytes);
int arbolVacio(const tArbol *pa);

void crearArbol(tArbol *pa);
void recorerEnOrden(const tArbol *pa, void (*mostrar)(const void *)) ;
void recorerEnPostOrden(const tArbol *pa, void (*mostrar)(const void *));
void recorerEnPreOrden(const tArbol *pa);

int contarNodos(const tArbol *pa);
int contarHojas(const tArbol *pa);
int contarHojasInternas(const tArbol *pa);
int contarHojasExternas(const tArbol *pa);
int contarNodosHastaNivelN(const tArbol *pa, int n);

int mostrarNumeroNodo(const tArbol *pa,void (*mostrar)(const void *) );
int mostrarRecursivo(const tArbol *pa, int num, void (*mostrar)(const void *));

void mostrarPersona(const void *d);
void mostrar_arbol(tArbol *pa, int cant);
void mostrar_arbol_horizontal(tArbol *pa);

int alturaArbol(const tArbol *pa);
int esCompleto(const tArbol *pa);
int esBalancead(const tArbol *pa);
int esAvl(const tArbol *pa);
void validarTipoDeArbol(const tArbol *pa);

int insertarEnArbol(tArbol *pa, const void *d, unsigned tamInfo, int (*comp)(const void *, const void *));
int buscarEnArbol(const tArbol *pa, void *d, unsigned cantBytes);



#endif // ARBOL_H_INCLUDED
