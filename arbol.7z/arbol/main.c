#include "arbol.h"

int comparar_(const void * n1, const void *n2)
{
    return n1 - n2;
}
int compararXDni(const void *d1, const void *d2)
{
    tPer *de1= (tPer *)d1;
    tPer *de2= (tPer *)d2;

    return de1->dni - de2->dni;
}

void probarArbolVector();
void probarArbolTper();

int main()
{
//    probarArbolVector();
    probarArbolTper();
    return 0;
}

void probarArbolVector()
{
    tArbol arbol;
    int vec[]= {50,40,20,30,60,70};
    int cont=0;

    crearArbol(&arbol);
    puts("\nInsertando en el arbol\n");

    for(cont=0; cont < 6; cont++)
    {
        insertarEnArbol(&arbol,vec,sizeof(int),comparar_);
        printf("\nInsertando dato %d \nValor %d\n", cont, vec[cont]);

    }
    if(!insertarEnArbol(&arbol,vec,sizeof(int),comparar_))
        printf("\nNo se pudo insertar en el arbol  :(\n");

    printf("\nel arbol tiene %d nodos",contarNodos(&arbol));
}

void generarArchivo(const char * path)
{
    FILE *pf;
    tPer vec[]={
        {"Karla Lorena Ledezma",100,'f'},
        {"Axel De Arias",50,'m'},
        {"Christian RIveros",25,'m'},
        {"Lucas Arzola",75,'m'},
        {"Damian Gutierrez",150,'m'},
        {"Fabian Cordoba",125,'m'},
        {"Lucas Flores",175,'m'}
//        {"Natalia Natalia",200,'f'}
    };
    pf=fopen(path,"wb");

    if(!pf)
        {
            printf("\nError creando el arch\n");
            return;
        }

    fwrite(&vec,sizeof(vec),1,pf);

    fclose(pf);


}
void probarArbolTper()
{
    tArbol arbol;
    char path[]="personas.dat";
    FILE *pf;
    tPer persona;
    int cont=0;

    crearArbol(&arbol);
    puts("\nGenerando lote de archivo\n");
    generarArchivo(path);
    pf=fopen(path,"rb");

    if(pf==NULL)
    {
        printf("\nError abriendo el archivo en md lectura\n");
        return;
    }
    fread(&persona,sizeof(persona),1,pf);
    puts("\nInsertando en el arbol\n");
    while(!feof(pf))
    {
//        if(!arbolLLeno(&arbol,sizeof(tPer)))
//            {
                    insertarEnArbol(&arbol,&persona,sizeof(tPer),compararXDni);
                    cont++;
//            }

        fread(&persona,sizeof(persona),1,pf);
    }
    printf("\n Se insertaron en el arbol %d nodos\n",cont);
    mostrarNumeroNodoEInformar(&arbol,mostrarPersona);
    puts("\nArbol horizontal\n");
    mostrar_arbol_horizontal(&arbol);

    puts("\nRecorrer arbol en orden\n");

    recorerEnOrden(&arbol, mostrarPersona);

    puts("\nRecorrer arbol en post orden\n");
    recorerEnPostOrden(&arbol,mostrarPersona);

    puts("\nContar hojas\n");
    printf("\nHay %d hojas\n", contarHojas(&arbol));

    puts("\nValidar tipo de arbol\n");
    printf("\nAltura arbol=%d\n", alturaArbol(&arbol));
    validarTipoDeArbol(&arbol);
}
