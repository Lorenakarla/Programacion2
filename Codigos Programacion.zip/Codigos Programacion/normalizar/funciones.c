#include "funciones.h"

char *Normalizar(char *cad)
{
    int cont = 0;
    char *destino = cad, *origen = cad;
    while(*origen)
    {
        while(*origen && !ES_LETRA(*origen))
            origen++;
        if(ES_LETRA(*origen))
        {
            *destino = aMayusc(*origen);
            destino++;
            origen++;
        }
        while(*origen && ES_LETRA(*origen))
        {
            *destino = aMinusc(*origen);
            destino++;
            origen++;
        }
        if(*origen && cont == 0)
        {
            *destino = ',';
            destino++;
            *destino = ' ';
            destino++;
            origen++;
            cont = 1;
        }
        else if(*origen)
        {
            *destino = ' ';
            destino++;
            origen++;
        }

    }
    if(destino > cad && esBlanco(*(destino-1)))
    {
        destino--;
    }
    *destino = '\0';
    return cad;
}
