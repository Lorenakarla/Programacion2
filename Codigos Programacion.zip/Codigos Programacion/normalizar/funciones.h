#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define esBlanco(x) ((x) == ' ' || (x) == '\t' ? 1:0)
#define aMayusc(x) ((x) > 'a' && (x) < 'z' ? (x)-32 : (x))
#define aMinusc(x) ((x) > 'A' && (x) < 'Z' ? (x)+32 : (x))
#define ES_LETRA(X) ((X>='A'&&X<='Z')||(X>='a'&&X<='z'))?1:0
#define ES_MAYU(X)  (X>='A'&&X<='Z')?1:0
#define ES_MINUS    (X>='a'&&X<='z'))?1:0

char *Normalizar(char *);
