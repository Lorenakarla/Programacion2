#include "funciones.h"

int main()
{
    char cadena[] = "   Perez,,,,Pablo,    Alejandro,,,,,           ";
    printf("la cadena es:%s\n", cadena);
    Normalizar(cadena);
    printf("la cadena normalizada es:%s.\n", cadena);

    return 0;
}
