#include "funciones.h"

void *mem_cpy(void *cad1, void *cad2, size_t cant)
{
    void *auxi = cad1;
    while(cant)
    {
        *(char *)cad1 = *(char *)cad2;
        cad1++;
        cad2++;
        cant--;
    }
    return auxi;
}
