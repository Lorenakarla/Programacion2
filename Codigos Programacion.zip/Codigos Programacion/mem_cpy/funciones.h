#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void *mem_cpy(void *cad1, void *cad2, size_t cant);
