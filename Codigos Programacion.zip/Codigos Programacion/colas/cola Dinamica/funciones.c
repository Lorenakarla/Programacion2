#include "funciones.h"


void crearCola(t_cola *p)
{
    p->ult = NULL;
    p->pri = NULL;
}

int colaLlena(const t_cola *p)
{
    void *aux = malloc(sizeof(t_nodo));
    free(aux);
    return aux == NULL ? 1: 0;
}

int colaVacia(const t_cola *p)
{
    return p->ult == NULL ? 1 : 0;
}


int verPrimero(const t_cola *p, t_info *d)
{
    if(p->ult == NULL)
        return 0;
    *d = p->pri->info;
    return 1;
}

int sacarDeCola(t_cola *p, t_info *d)
{
    if(p->ult == NULL)
        return 0;
    t_nodo *aux;
    aux = p->pri;
    *d  = aux->info;
    if(p->pri == p->ult)
    {
        p->ult = NULL;
        p->pri = NULL;
    }
    else
        p->pri = aux->sig;
    free(aux);
}


int ponerEnCola(t_cola *p, const t_info *d)
{
    t_nodo *nue = (t_nodo *)malloc(sizeof(tnodo));
    if(aux == NULL)
        return 0;
    if(p->ult == NULL)
        p->pri = nue;
    else
        p->ult->sig = nue;
    nue->info = *d;
    nue->sig = NULL;
    p->ult = nue;
    return 1;
}


void vaciarCola(t_cola *p)
{
    t_nodo *aux;
    while(*aux)
    {
        aux = p->pri;
        p->pri = aux->sig;
        free(aux);
    }
    p->ult = NULL;
}
