#include <stdio.h>
#include <stdlib.h>


typedef struct
{
    int num;
}t_info;

typedef struct s_nodo
{
    t_info info;
    struct s_nodo *sig;
}t_nodo;

typedef struct
{
    t_nodo *pri, *ult;
}t_cola;


void crearCola(t_cola *);
int colaVacia(const t_cola *);
int colaLlena(const t_cola *);
int verPrimero(const t_cola *, t_info *);
int sacarDeCola(t_cola *, t_info *);
int ponerEnCola(t_cola *, const t_info *);
void vaciarCola(t_cola *);
