#include "funciones.h"


void crearcola(t_cola *p)
{
    *p = NULL;
}

int colallena(const t_cola *p)
{
    void *aux = malloc(sizeof(t_nodo));
    free(aux);
    return aux==NULL;
}

int colavacia(const t_cola *p)
{
    return *p == NULL;
}

void vaciarcola(t_cola *p)
{
    t_nodo *aux;
    while(*p)
    {
        aux = (*p)->sig;
        if(aux == *p)
            *p = NULL;
        else
            (*p)->sig = aux->sig;
        free(aux);
    }
}

int verprimero(const t_cola *p, t_info *d)
{
    if(*p == NULL)
        return 0;
    *d = (*p)->sig->info;
    return 1;
}

int desacolar(t_cola *p, t_info *d)
{
    t_nodo *aux;
    if(*p == NULL)
        return 0;
    aux = (*p)->sig
    *d = aux->info;
    if(aux == *p)
        *p = NULL;
    else
        (*p)->sig = aux->sig;
    free(aux);
    return 1;

}

int acolar(t_cola *p, const t_info *d)
{
    t_nodo *nue = (t_nodo *)malloc(sizeof(t_nodo));
    if(nue == NULL)
        return 0;
    nue->info = *d;
    if(*p == NULL)
        nue->sig = nue;
    else
    {
        nue->sig = (*p)->sig;
        (*p)->sig = nue;
    }
    *p = nue;
    return 1;
}
