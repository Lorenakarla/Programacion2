#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int codigo;
}t_info;

typedef struct s_nodo
{
    t_info info;
    struct s_nodo *sig;
}t_nodo;

typedef t_nodo *t_cola;

int abrirarchivo(FILE **, const char *, const char *);
void crearcola(t_cola *);
int colavacia(const t_cola *);
int colallena(const t_cola *);
int acolar(t_cola *, const t_info *);
int desacolar(t_cola *, t_info *);
void vaciarcola(t_cola *);
int verprimero(const t_cola*, t_info *);
int cargarinfo(t_info *info);

