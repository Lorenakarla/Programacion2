#include <stdio.h>
#include <stdlib.h>
#define TAM_COLA 5

typedef struct
{
    int num;
}t_info;

typedef struct
{
    t_info cola[TAM_COLA];
    int pri, ult, cantCargados;
}t_cola;


void crearCola(t_cola *);
int colaVacia(const t_cola *);
int colaLlena(const t_cola *);
int verPrimero(const t_cola *, t_info *);
int sacarDeCola(t_cola *, t_info *);
int ponerEnCola(t_cola *, const t_info *);
void vaciarCola(t_cola *);
