#include "funciones.h"

void crearCola(t_cola *p)
{
    p->pri = 0;
    p->ult = 0;
    p->cantCargados = 0;
}

int colaLlena(const t_cola *p)
{
    return p->cantCargados == TAM_COLA;
}

int colaVacia(const t_cola *p)
{
    return p->cantCargados == 0;
}

int verPrimero(const t_cola *p, t_info *d)
{
    if(p->cantCargados == 0)
        return 0;
    *d = p->cola[p->pri];
    return 1;
}

int sacarDeCola(t_cola *p, t_info *d)
{
    if(p->cantCargados == 0)
        return 0;

    *d = p->cola[p->pri];
    p->pri++;

    if(p->pri == TAM_COLA)
        p->pri = 0;

    p->cantCargados--;

    return 1;
}

int ponerEnCola(t_cola *p, const t_info *d)
{
    if(p->cantCargados == TAM_COLA)
        return 0;

    p->cola[p->ult] = *d;
    p->ult++;
    if(p->ult == TAM_COLA)
        p->ult = 0;
    p->cantCargados++;
    return 1;
}

void vaciarCola(t_cola *p)
{
    p->cantCargados = 0;
}
