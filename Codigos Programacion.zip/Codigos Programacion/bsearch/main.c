#include "funciones.h"
int main()
{
    int i;
    t_persona pers[6]={{"Z", "A", 5},
                       {"A", "B", 10},
                       {"M", "C", 4},
                       {"A", "B", 7},
                       {"M", "M", 9},
                       {"A", "B", 3}};
    t_persona key, *aux;

    /*imprimo el array*/
    printf("array sin ordenar\n\n");
    for(i = 0; i< 6; i++)
    {
        printf("apellido: %s\nnombre: %s\nedad: %d\n\n", pers[i].apellido, pers[i].nombre, pers[i].edad);
    }

    key = pers[3]; /*asigno la posicion 4 del array de estructuras a la llave */

    qsort(pers, 6, sizeof(t_persona), compararPersona);

    /*imprimo el array ordenado */
    printf("array ordenado\n\n");
    for(i = 0; i< 6; i++)
    {
        printf("apellido: %s\nnombre: %s\nedad: %d\n\n", pers[i].apellido, pers[i].nombre, pers[i].edad);
    }
    /* la posicion de la llave en el vector cambia una vez ordenado a la pos 1*/
    aux = bsearch(&key, pers, 6, sizeof(t_persona), compararPersona);
    printf("Apellido de la key: %s\nnombre de la key: %s\nedad de la key: %d\ndireccion devuelta por bsearch: %p\ndireccion de la key en el vector: %p\n",
            aux->apellido, aux->nombre, aux->edad, aux, &pers[1]); /* la posicion de la llave en el vector cambia una vez ordenado a la pos 1*/

    return 0;
}
