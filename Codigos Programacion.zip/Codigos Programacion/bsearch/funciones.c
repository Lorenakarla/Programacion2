#include "funciones.h"

int compararPersona(const void *d1, const void *d2)
{
    int aux;
    t_persona *dato1,
              *dato2;

    dato1 = (t_persona *)d1;
    dato2 = (t_persona *)d2;

    aux = strcmp(dato1->apellido, dato2->apellido);

    if(aux != 0)
        return aux;
    else
    {
        aux = strcmp(dato1->nombre, dato2->nombre);
        if(aux != 0)
            return aux;
        else
        {
            return dato1->edad - dato2->edad;
        }
    }


}
