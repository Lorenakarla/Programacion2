#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 30

typedef struct
{
    char apellido[TAM];
    char nombre[TAM];
    int edad;
}t_persona;

int compararPersona(const void *, const void *);
