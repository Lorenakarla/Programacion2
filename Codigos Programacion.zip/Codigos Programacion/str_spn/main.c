#include "funciones.h"

int main()
{
    char cad1[]="hola mundo";
    char cad2[]="holakc";
    printf("\n%d\n", str_spn(cad1, cad2));
    return 0;
}
