#include "funciones.h"

int main()
{
    FILE *fpbin, *fptxtvar, *fptxtfijo, *fpSal;
    t_pers persona[3]={{"perez", "maria", 20} ,{"del cerro", "juan pablo", 22},{"pratto", "marco aurelio", 30}};
    t_pers pers;

    fpbin = fopen("archivo.bin", "wb");

    if(fpbin==NULL)
        return TODO_MAL;

    fwrite(persona, sizeof(persona),1, fpbin);

    fclose(fpbin);
     /* abro el archivo binario para crear 2 de texto, longitud fija y variable */

    fpbin = fopen("archivo.bin", "rb");

    if(fpbin==NULL)
        return TODO_MAL;

    fptxtvar = fopen("archivotxtvar.txt", "wt");
    fptxtfijo = fopen("archivotxtfijo.txt", "wt");

    if(fptxtvar == NULL)
    {
        fclose(fpbin);
        return TODO_MAL;
    }
    if(fptxtfijo == NULL)
    {
        fclose(fpbin);
        fclose(fptxtvar);
        return TODO_MAL;
    }
    fread(&pers, sizeof(t_pers), 1, fpbin);
    while(!feof(fpbin))
    {
        fprintf(fptxtvar,"%s|%s|%d\n", pers.Apellido, pers.nombre, pers.edad);
        fprintf(fptxtfijo, "%-*s%-*s%03d\n", sizeof(pers.Apellido), pers.Apellido, sizeof(pers.nombre), pers.nombre, pers.edad);
        fread(&pers, sizeof(t_pers), 1, fpbin);
    }
    fclose(fptxtvar);
    fclose(fptxtfijo);
    fclose(fpbin);


    return 0;
}
