#include <stdio.h>
#include <stdlib.h>
#define TODO_MAL 1

typedef struct
{
    char Apellido[20];
    char nombre[20];
    int edad;
}t_pers;
