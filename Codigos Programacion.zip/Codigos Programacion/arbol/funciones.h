#include <stdio.h>
#include <stdlib.h>
#define CLA_DUP 0
#define PRE_ORDEN 1
#define EN_ORDEN 2
#define POS_ORDEN 3

typedef struct
{
    int num;
}t_info;

typedef struct s_nodo
{
    t_info info;
    struct s_nodo *izq, *der;
}t_nodo;

typedef t_nodo *t_arbol;

int cargarInfo(t_info *);
int compararNodos(t_info *, t_info *);
int arbolLleno(const t_arbol *);
void mostrar(const t_info *);
void enOrden(const t_arbol *);
void posOrden(const t_arbol *p);
void preOrden(const t_arbol *p);
void crearArbol(t_arbol *);
int ponerEnArbol(t_arbol *, const t_info *);
int contarNodos(const t_arbol *);
int contarHojas(const t_arbol *);
int contarNodosNoHojas(const t_arbol *);
int alturaArbol(const t_arbol *);
int nodosInternos(const t_arbol *p);
int esAVL(const t_arbol *);
void eliminarArbol(t_arbol *p);
int eliminarArbolGrabarYContar(t_arbol *p, int ,FILE *fp);
int esCompleto(const t_arbol *p);
int verSiEsCompleto(t_arbol *p, int alt);
int esBalanceado(const t_arbol *p);
int verSiEsBalanceado(const t_arbol *p, int alt);
int determinarBalanceo(const t_arbol *);
int ContarNodosHastaElNivelX(const t_arbol *p, int nivel);
void eliminarHastaNivelX(t_arbol *, int );
void Borrar(t_arbol *a, int dat);
