#include "funciones.h"


int cargarInfo(t_info *d)
{
    printf("ingrese valor: \n");
    scanf("%d", &d->num);
    if(d->num == 0)
        return 0;
    return 1;
}

int compararNodos(t_info *d1, t_info *d2)
{
    return d1->num - d2->num;
}

void mostrar(const t_info *d)
{
    printf("el contenido del nodo es %d\n", d->num);
}

int arbolLleno(const t_arbol *p)
{
    void *aux = malloc(sizeof(t_nodo));
    free(aux);
    return aux == NULL ? 1:0;
}

void crearArbol(t_arbol *p)
{
    *p = NULL;
}

void enOrden(const t_arbol *p)
{
    if(*p)
    {
        enOrden(&(*p)->izq);
        mostrar(&(*p)->info);
        enOrden(&(*p)->der);
    }
}

void preOrden(const t_arbol *p)
{
    if(*p)
    {
        mostrar(&(*p)->info);
        preOrden(&(*p)->izq);
        preOrden(&(*p)->der);
    }
}

void posOrden(const t_arbol *p)
{
    if(*p)
    {
        posOrden(&(*p)->izq);
        posOrden(&(*p)->der);
        mostrar(&(*p)->info);
    }
}

int ponerEnArbol(t_arbol *p, const t_info *d)
{
    int cmp;
    t_nodo *nue = malloc(sizeof(t_nodo));
    if(nue==NULL)
        return 0;
    while(*p)
    {
        cmp = compararNodos(&(*p)->info, (t_info *)d);
        if(cmp == 0)
            return CLA_DUP;
        else if(cmp > 0)
            p = &(*p)->izq;
        else
            p = &(*p)->der;
    }
    nue->der = NULL;
    nue->izq = NULL;
    nue->info = *d;
    *p = nue;
    return 1;
}

int contarNodos(const t_arbol *p)
{
    if(*p)
    {
        return contarNodos(&(*p)->izq)+contarNodos(&(*p)->der)+1;
    }
    return 0;
}

int contarHojas(const t_arbol *p)
{
    if(*p)
    {
        if((*p)->izq == NULL && (*p)->der == NULL)
            return 1;
        return contarHojas(&(*p)->izq)+contarHojas(&(*p)->der);
    }
    return 0;
}

int contarNodosNoHojas(const t_arbol *p)
{
    if(*p)
    {
        return contarNodosNoHojas(&(*p)->izq)+contarNodosNoHojas(&(*p)->der)+((*p)->izq != NULL || (*p)->der != NULL ? 1:0);
    }
    return 0;
}

int alturaArbol(const t_arbol *p)
{
    if(*p)
    {
        int hi = alturaArbol(&(*p)->izq);
        int hd = alturaArbol(&(*p)->der);
        return hi > hd ? hi+1:hd+1;
    }
    return 0;
}

int nodosInternos(const t_arbol *p) /** CUENTA LOS NODOS QUE TIENEN RAMAS POR UN SOLO LADO **/
{
    if(*p)
    {
        return nodosInternos(&(*p)->izq)+nodosInternos(&(*p)->der)+(((*p)->izq == NULL && (*p)->der) || ((*p)->izq && (*p)->der == NULL)?1:0);
    }
    return 0;
}

int esAVL(const t_arbol *p)  /** ARBOL SEMI-BALANCEADO (CADA NODO TIENE DIFERENCIA DE MAXIMO 1 ENTRE ALTURA DE DERECHA E IZQUIERDA)**/
{
    if(*p)
    {
        if(abs(alturaArbol(&(*p)->izq) - alturaArbol(&(*p)->der))>1)
            return 0;
        return esAVL(&(*p)->izq)&&esAVL(&(*p)->der);
    }
    return 1;
}

void eliminarArbol(t_arbol *p)
{
    if(*p)
    {
        eliminarArbol(&(*p)->izq);
        eliminarArbol(&(*p)->der);
        free(*p);
        *p = NULL;
    }
}

int eliminarArbolGrabarYContar(t_arbol *p, int indic, FILE *fp)
{
    int cant;
    if(*p)
    {
        if(indic == PRE_ORDEN)
            fwrite(&(*p)->info, sizeof(t_info), 1, fp);
        cant = eliminarArbolGrabarYContar(&(*p)->izq, indic, fp);
        if(indic == EN_ORDEN)
            fwrite(&(*p)->info, sizeof(t_info), 1, fp);
        cant += eliminarArbolGrabarYContar(&(*p)->der, indic, fp);
        if(indic == POS_ORDEN)
            fwrite(&(*p)->info, sizeof(t_info), 1, fp);

        free(*p);
        *p = NULL;
        return cant+1;
    }
    return 0;
}

int esCompleto(const t_arbol *p)
{
    int altura = alturaArbol(p);
    return verSiEsCompleto((t_arbol *)p, altura);
}

int verSiEsCompleto(t_arbol *p, int alt)
{
    if(*p)
    {
        return verSiEsCompleto(&(*p)->izq, alt-1) && verSiEsCompleto(&(*p)->der, alt-1);
    }
    return alt==0;
}

int verSiEsBalanceado(const t_arbol *p, int h)
{
    if(*p)
    {
        return verSiEsBalanceado(&(*p)->izq, h-1) && verSiEsBalanceado(&(*p)->der, h-1);
    }
    return h<=1;
}

int esBalanceado(const t_arbol *p)
{
    int h = alturaArbol(p);
    return verSiEsBalanceado(p, h);
}

int determinarBalanceo(const t_arbol *p)
{
    int x = esBalanceado(p);
    if(x == 1)
        return 3; //Pos-orden
    else
    {
        x = esCompleto(p);
        if(x == 1)
            return 4;
        else
        {
            x = esAVL(p);
            if( x == 1)
                return 2; //En-orden
            else
                return 1; //Pre-orden
        }
    }
}

int ContarNodosHastaElNivelX(const t_arbol *p, int nivel)
{
    if(*p)
    {
        if(nivel)
        {
            return ContarNodosHastaElNivelX(&(*p)->izq, nivel-1)+ContarNodosHastaElNivelX(&(*p)->der, nivel-1)+1;
        }
    }
    return 0;
}

void eliminarHastaNivelX(t_arbol *p, int nivel)
{
   if(*p)
   {
       if(nivel)
       {
           eliminarHastaNivelX(&(*p)->izq, nivel-1);
           eliminarHastaNivelX(&(*p)->der, nivel-1);
       }
       if(nivel==0)
            eliminarArbol(p);
   }

}

void Borrar(t_arbol *a, int dat)
{
    t_nodo *padre = NULL;
    t_nodo *actual;
    t_nodo *nodo;
    int aux;

    actual = *a;
    while(actual)
    {
        if(dat == actual->info.num)
        {
            if(actual->der == NULL && actual->izq == NULL)
            {
                if(padre)
                {
                    if(padre->der == actual)
                        padre->der = NULL;
                    else if(padre->izq == actual)
                        padre->izq = NULL;
                free(actual);
                actual = NULL;
                return;
            }
            else
            {
                padre = actual;
                if(actual->der)
                {
                    nodo = actual->der;
                    while(nodo->izq)
                    {
                        padre = nodo;
                        nodo = nodo->izq;
                    }
                }
                else
                {
                    nodo = actual->izq;
                    while(nodo->der)
                    {
                        padre = nodo;
                        nodo = nodo->der;
                    }
                }

                aux = actual->info.num;
                actual->info = nodo->info;
                nodo->info.num = aux;
                actual = nodo;
            }
        }

        else{
                padre = actual;
                if(dat > actual->info.num)
                    actual = actual->der;
                else if(dat < actual->info.num)
                    actual = actual->izq;
            }
        }
    }
}
