#include "funciones.h"

int main()
{
    t_arbol arbol;
    t_info info;
    int alt = 0;

    //FILE *fp = fopen("arbol.bin", "wb");
    crearArbol(&arbol);
    while(!arbolLleno(&arbol) && cargarInfo(&info))
    {
        ponerEnArbol(&arbol, &info);
    }
    preOrden(&arbol);

    alt = alturaArbol(&arbol);
    printf("\nLa altura del arbol es: %d", alt);

    /**printf("elimino\n");
    eliminarHastaNivelX(&arbol, 3);
    preOrden(&arbol);**/

    return 0;
}
