#include <string.h>
#include <stdio.h>
#include <stdlib.h>

size_t str_cspn(char *, char *);
