#include "funciones.h"

int main()
{
    char cad1[]="pepe mundo";
    char cad2[]="hola";
    printf("\n%d\n", str_cspn(cad1, cad2));
    return 0;
}
