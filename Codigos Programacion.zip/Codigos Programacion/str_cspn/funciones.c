#include "funciones.h"


size_t str_cspn(char *cad1, char *cad2)
{
    size_t cant=0;
    while(*cad1 && !strchr(cad2, *cad1))
    {
        cad1++;
        cant++;
    }
    return cant;
}
