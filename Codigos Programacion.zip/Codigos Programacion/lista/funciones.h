#include <stdio.h>
#include <stdlib.h>
#define CLA_DUP 118

typedef struct
{
    int num;
}t_info;

typedef struct s_nodo
{
    t_info info;
    struct s_nodo *sig;
}t_nodo;

typedef t_nodo *t_lista;

int ingresarInfo(t_info *);
int comparar(const t_info *d1, const t_info *d2);
void acumular(t_info *, t_info *);
void crearLista(t_lista *);
int listaLlena(const t_lista *);
int ingresarAlFinal(t_lista *, const t_info *);
int insertarEnOrden(t_lista *, const t_info *);
int eliminarDuplicadosOrdenada(t_lista *, FILE *);
int eliminarDuplicadosNoOrdenada(t_lista *, FILE *);
void ordenarLista(t_lista *);
int listaVacia(const t_lista *);
int sacarPrimeroLista(t_lista *, t_info *);
int sacarUltimoLista(t_lista *, t_info *);
int eliminarUnicosOrdenada(t_lista *, FILE *);
int eliminarUnicosNoOrdenada(t_lista *, FILE *);
void vaciarLista(t_lista *);
int insertarAlComienzo(t_lista *, const t_info *);
