#include "funciones.h"


int ingresarInfo(t_info *d)
{
    do
    {
        printf("ingrese num: ");
        scanf("%d", &d->num);
        if(d->num == 0)
            return 0;
    }while(d->num < 0);
    return 1;
}

int comparar(const t_info *d1, const t_info *d2)
{
    return d1->num - d2->num;
}

void acumular(t_info *d1, t_info *d2)
{
    d1->num += d2->num;
}
void crearLista(t_lista *p)
{
    *p = NULL;
}

int listaLlena(const t_lista *p)
{
    void *aux = malloc(sizeof(t_nodo));
    free(aux);
    return aux == NULL ? 1:0;
}

int ingresarAlFinal(t_lista *p, const t_info *d)
{
    t_nodo *nue;
    while(*p)
        p = &(*p)->sig;
    nue = (t_nodo *)malloc(sizeof(t_nodo));
    if(nue == NULL)
        return 0;
    nue->info = *d;
    nue->sig = NULL;
    *p = nue;
    return 1;
}

int insertarEnOrden(t_lista *p, const t_info *d)
{
    t_nodo *nue;
    while(*p && comparar(&(*p)->info, d)<0)
        p = &(*p)->sig;
    if(*p && comparar(&(*p)->info, d) ==0)
    {
        acumular(&(*p)->info, (t_info *)d);
        return CLA_DUP;
    }
    nue = (t_nodo *)malloc(sizeof(t_nodo));
    if(nue==NULL)
        return 0;
    nue->sig = *p;
    *p = nue;
    nue->info = *d;
    return 1;
}

int eliminarDuplicadosOrdenada(t_lista *p, FILE *fp)
{
    t_nodo *aux;
    while(*p)
    {
        while((*p)->sig && comparar(&(*p)->info, &(*p)->sig->info)==0)
        {
            aux = *p;
            fwrite(&aux->info, sizeof(t_nodo), 1, fp);
            *p = aux->sig;
            free(aux);
        }
        p = &(*p)->sig;
    }
    return 1;
}
int eliminarDuplicadosNoOrdenada(t_lista *p, FILE *fp)
{
    t_lista *q;
    int cont=0;
    t_nodo *aux;
    while(*p && (*p)->sig)
    {
        q  = &(*p)->sig; ;
        while(*q)
        {
            if(comparar(&(*p)->info, &(*q)->info)==0)
            {

                aux = *q;
                *q = aux->sig;
                fwrite(&aux, sizeof(t_nodo), 1, fp);
                cont++;
                free(aux);
            }
            else
                q = &(*q)->sig;
        }
        p = &(*p)->sig;
    }
    return cont;
}
void ordenarLista(t_lista *p)
{
    int bandera = 1;
    t_nodo *aux;
    t_lista *q;
    while(*p && bandera )
    {
        bandera = 0;
        q = p;
        while((*q)->sig)
        {
            if(comparar(&(*q)->info, &(*q)->sig->info)>0)
            {
                aux = *q;
                bandera = 1;
                *q = aux->sig;
                aux->sig = (*q)->sig;
                (*q)->sig = aux;
            }
            else
                q = &(*q)->sig;
        }

    }
}

int listaVacia(const t_lista *d)
{
    return *d == NULL;
}

int sacarPrimeroLista(t_lista *p, t_info *d)
{
    t_nodo *aux;
    if(*p==NULL)
        return 0;
    *d = (*p)->info;
    aux = *p;
    *p = aux->sig;
    free(aux);
    return 1;
}


int sacarUltimoLista(t_lista *p, t_info *d)
{
    if(*p == NULL)
        return 0;
    while((*p)->sig)
        p = &(*p)->sig;
    *d = (*p)->info;
    free(*p);
    *p = NULL;
    return 1;
}

int eliminarUnicosOrdenada(t_lista *p, FILE *fp)
{
    t_nodo *aux;
    t_lista *q;
    while(*p)
    {
        q = &(*p)->sig;
        if(*q == NULL  || comparar(&(*p)->info, &(*q)->info)!=0)
        {
            aux = *p;
            *p = aux->sig;
            fwrite(&aux, sizeof(t_nodo), 1, fp);
            free(aux);
        }
        else
        {
            while(*q && comparar(&(*p)->info, &(*q)->info) == 0)
            {
                q = &(*q)->sig;
            }
            p = q;
        }
    }
    return 1;
}


int eliminarUnicosNoOrdenada(t_lista *p, FILE *fp)
{
    t_lista *q, *inicio = p;
    t_nodo *aux;
    while(*p)
    {
        q = inicio;
        while((*q == *p) || (*q  && comparar(&(*p)->info, &(*q)->info)!=0))
            q = &(*q)->sig;
        if(*q)
        {
            p = &(*p)->sig;
        }
        else
        {
            aux = *p;
            *p = aux->sig;
            fwrite(&aux, sizeof(t_nodo), 1, fp);
            free(aux);
        }
    }
    return 1;
}

void vaciarLista(t_lista *p)
{
    t_nodo *aux;
    while(*p)
    {
        aux = *p;
        *p = aux->sig;
        free(aux);
    }
}

int insertarAlComienzo(t_lista *p, const t_info *d)
{
    t_nodo *nue = (t_nodo *)malloc(sizeof(t_nodo));
    if(nue == NULL)
        return 0;
    nue->info = *d;
    nue->sig = *p;
    *p = nue;
}
