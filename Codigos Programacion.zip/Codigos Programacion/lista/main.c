#include "funciones.h"

int main()
{
    t_lista lista;
    t_info info;
    FILE *fp = fopen("duplicados.bin", "wb");

    crearLista(&lista);
    while(!listaLlena(&lista)&&ingresarInfo(&info))
    {
        ingresarAlFinal(&lista, &info);
    }
    eliminarUnicosNoOrdenada(&lista, fp);

    while(!listaVacia(&lista))
    {
        sacarPrimeroLista(&lista, &info);
        printf("el num es: %d\n", info.num);
    }

    return 0;
}
