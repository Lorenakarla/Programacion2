#include "funciones.h"

int EsPalindromo(char *cad)
{
    char *fin;
    fin = strrchr(cad, '\0');
    fin--;
    while(cad <= fin)
    {
        if((A_MINUSC(*cad)) == (A_MINUSC(*fin)))
        {
            cad++;
            fin--;
        }
        else if(ES_BLANCO(*cad))
            cad++;
        else if(ES_BLANCO(*fin))
            fin--;
        else
            return 0;
    }
    return 1;
}
