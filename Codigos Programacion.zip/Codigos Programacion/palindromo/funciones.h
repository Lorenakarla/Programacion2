#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ES_BLANCO(X) (X)==' '?1:0
#define A_MINUSC(X) (X)>='A'&&(X)<='Z'?(X)+32:(X)

int EsPalindromo(char *);
