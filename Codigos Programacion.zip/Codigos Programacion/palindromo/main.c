#include "funciones.h"

int main()
{
    char cad[] = "anita lava la tinA";
    if(EsPalindromo(cad))
        printf("la cadena \"%s\" es palindromo", cad);
    else
        printf("la cadena \"%s\" NO es palindromo", cad);
    return 0;
}
