#include "funciones.h"

int main()
{
    char cad[]="hola";
    printf("*");
    imprimir4(cad);
    printf("*");
    return 0;
}
