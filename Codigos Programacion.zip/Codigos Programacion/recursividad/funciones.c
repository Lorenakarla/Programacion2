#include "funciones.h"

int factorial(int x)
{
    int aux=1;
    if(x)
        aux = x * factorial(x-1);
    return aux;

}

void imprimir1(char *cad)
{
    if(*cad)
    {
        printf("%c", *cad);
        imprimir1(cad+1);
    }
    return;
}
void imprimir2(char *cad)
{
    if(*cad)
    {
        imprimir2(cad+1);
        printf("%c", *cad);
    }
    return;
}
void imprimir3(char *cad)
{
      if(*cad)
    {
        printf("%c", *cad);
        imprimir3(cad+1);
        if(*(cad+1)=='\0')
            return;
        printf("%c", *cad);
    }
    return;
}

void imprimir4(char *cad)
{
      if(*cad)
    {
        imprimir4(cad+1);
        while(*cad)
        {
            printf("%c", *cad);
            cad++;
        }
        printf("\n");
    }
    return;
}

void imprimir5(char *cad)
{
    if(*cad)
    {
        printf("%s\n", cad);
        imprimir5(cad+1);
    }
    return;
}
