#include <stdio.h>
#include <stdlib.h>
int factorial(int );
void imprimir(char *);
void imprimir2(char *cad);
void imprimir3(char *cad);
void imprimir4(char *cad);
void imprimir5(char *cad);
