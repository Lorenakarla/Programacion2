#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *strn_cpy(char *, char *, size_t );
