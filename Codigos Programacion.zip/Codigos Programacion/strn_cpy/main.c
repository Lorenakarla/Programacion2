#include "funciones.h"

int main()
{
    char cad2 [] = "hola mundo";
    char cad1[30];
    int cant= 3;
    printf("cad1 : %s", cad1);
    strncpy(cad1, cad2, cant);
    printf("cad1: %s", cad1);
    return 0;
}
