#include "funciones.h"
char *strn_cpy(char *cad1, char *cad2, size_t cant)
{
    char *auxi = cad1;
    while(cant && cad2)
    {
        *cad1 = *cad2;
        cad1++;
        cad2++;
        cant--;
    }
    while(cant)
    {
        *cad1 = '\0';
        cant--;
    }
    return auxi;
}
