#include "funciones.h"

void *mem_move(void *dest, const void *orig, size_t cant)
{
    void *auxi = dest;
    if(orig >= dest)
        while(cant)
        {
            *((char *)dest) = *((char *)orig);
            dest++;
            orig++;
            cant--;
        }
    else
    {
        (char *)dest += cant - 1;
        (char *)orig += cant - 1;
        while(cant)
        {
            *((char *)dest) = *((char *)orig);
            dest--;
            orig--;
            cant--;
        }

    }
