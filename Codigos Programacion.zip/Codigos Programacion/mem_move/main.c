#include "funciones.h"
int main()
{
    char cad1[] = "abcdefg";
    char cad2[16];
    printf( "cad1: %s", cad1 );
    mem_move(cad2, cad1, 8 );
    printf( "\n" );
    printf( "cad2 = %s ",cad2);
    printf( "\n" );
    return 0;
}
