#include <stdio.h>
#include <stdlib.h>
#include <string.h>



void *mem_move(void *dest, const void *orig, size_t cant);
