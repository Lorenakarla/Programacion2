#ifndef RACIONAL_H_INCLUDED
#define RACIONAL_H_INCLUDED
#include <iostream>
#include <stdlib.h>


using namespace std;

class Racional{
private:
    int numerador;
    int denominador;

public:
    Racional(int = 0, int = 0);

    friend ostream& operator <<(ostream&, const Racional&);

    Racional operator + (const Racional&)const;
    Racional operator + (const int)const;
    friend Racional operator +(const int, const Racional&);
};


#endif // RACIONAL_H_INCLUDED
