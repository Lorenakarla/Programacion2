#include <iostream>
#include "Racional.h"

using namespace std;

int main()
{

    Racional num_uno(1, -2);
    Racional num_dos(-1, 3);
    Racional num_tres(-4, -3);
    Racional num_cuatro(4, 2);
    Racional num_cinco(8, 4);
    Racional num_resul(4, 2);


    cout << "Probando metodo 'cout' y colocacion correcta del signo negativo" << endl;
    cout << num_uno << endl;
    cout << num_dos << endl;
    cout << num_tres << endl;

    num_resul = num_uno + num_dos;
    cout << "\nProbando operador + sobrecarga1\n" << num_uno << " mas " << num_dos << " = " << num_resul << endl;

    num_resul = num_cuatro + 2;
    cout << "\nProbando operador + sobrecarga2\n" << num_cuatro << " mas 2 = " << num_resul << endl;

    num_resul = 2 + num_cinco;
    cout << "\nProbando operador + en funcion amiga\n" << "2 mas "<< num_cinco << " = " << num_resul << endl;

    return 0;
}
/**
int nodos_internos(t_arbol * parbol){

    if(*parbol == NULL)
        return 0;

    if((*parbol)->pder != NULL && (*parbol)->pizq != NULL){
        return  ( nodos_internos(&(*parbol)->pder) +
                nodos_internos(&(*parbol)->pizq) + 1)
    }
    else{
        return 0;
    }
}
*/
