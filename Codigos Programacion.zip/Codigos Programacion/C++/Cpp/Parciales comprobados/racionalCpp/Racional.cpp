#include "Racional.h"

using namespace std;

Racional :: Racional(int nume, int deno){
    this->numerador = nume;
    this->denominador = deno;
}

ostream& operator << (ostream& sal, const Racional& obj){
    Racional aux(obj);

    if(obj.denominador < 0){
        aux.denominador *= -1;
        aux.numerador *= -1;
    }

    sal << aux.numerador << '/' << aux.denominador;
    return sal;
}

Racional Racional :: operator + (const Racional& obj)const{
    Racional aux(*this);
    aux.numerador = ( this->numerador * obj.denominador )+( obj.numerador * this->denominador );
    aux.denominador = (this->denominador * obj.denominador);
    return aux;
}

Racional Racional :: operator + (const int var)const{
    Racional aux(*this);
    aux.numerador = ( this->numerador )+( var * this->denominador );
    aux.denominador = this->denominador;
    return aux;
}

Racional operator +(const int var, const Racional& obj){
    Racional aux;
    aux.numerador = ( var * obj.denominador )+( obj.numerador );
    aux.denominador = obj.denominador;
    return aux;
}
