#ifndef COMPLEJOS_H_INCLUDED
#define COMPLEJOS_H_INCLUDED

#include <iostream>

using namespace std;

class Complejo
{
public:
    Complejo(int real=0,int imag=0);
    ~Complejo();
    friend ostream& operator<<(ostream &sal,const Complejo &com);
    friend Complejo operator * (int d,const Complejo & com);
    Complejo operator * (const Complejo &com)const;

protected:

private:
    int real;
    int imag;
};

#endif // COMPLEJOS_H_INCLUDED
