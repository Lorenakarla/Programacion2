#include "complejos.h"

Complejo::Complejo(int r,int i)
{
    real=r;
    imag=i;
}

Complejo::~Complejo()
{
    //dtor
}

ostream& operator <<(ostream&sal,const Complejo &com)
{
    sal<<"("<<com.real<<","<<com.imag<<")"<<endl;
    return sal;
}

Complejo operator *(int d,const Complejo & com)
{
    //2(a,b)= (2*a,2*b);
    return Complejo(com.real*d,com.imag*d);
}

Complejo Complejo:: operator * (const Complejo &com)const
{
    //(a,b)*(c,d)= (a*c-b*d,a*d+b*c)
    Complejo aux;
    aux.real=(com.real * this->real) - (com.imag * this->imag);
    aux.imag=(com.real * this->imag) + (com.imag * this->real);

    return aux;

}
