#ifndef PUNTOCPP_H_INCLUDED
#define PUNTOCPP_H_INCLUDED
//define DEPURAR --> Si esta comentado no ejecutara lo que esta en la etiqueta "DEFINE"

class Punto {

	private;

		int x, y;


    friend Punto operator *( const int &n, const Punto &obj); //Como esta a la izquierza del objeto se usa una funcion amiga.
    //friend Punto operator *( int n, const Punto &obj);
    friend ostream & operator << ( ostream &sal, const Punto &obj );
    friend istream & operator >> ( istream &ent, Punto &obj );

	public;
		Punto( int =0, int =0 );

		//Punto operator*( int n )const; // El const del final indica que el objeto this no se modificia.
		Punto operator*( const int &n )const;

		bool operator > (const Punto &obj)const;

		Punto operator++(void); //pre
		Punto operator++(int); // post


#ifdef DEPURAR
	~Punto(void);
	Punto(const Punto &ob)
	Punto &operator= ( const Punto &obj );
#endif // DEPURAR

#endif // PUNTOCPP_H_INCLUDED
