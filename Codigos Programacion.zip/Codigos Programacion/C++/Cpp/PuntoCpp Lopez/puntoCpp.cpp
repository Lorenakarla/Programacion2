Punto::Punto( int x, int y ) {

	this -> x = x % 1920;

	if( this -> x < 0 )
		this -> x += 1920;

	this -> y = y % 1080

	if( this -> y < 0 )
		this -> y += 1080
#ifdef DEPURAR
	cout << "Creando el punto" << this << endl;
#endif // DEPURAR
}

Punto::Punto( const Punto &obj ){

	x = obj.x;
	y = obj.y;

	cout << "Constructor de copia objeto: " << this << endl;
}

Punto & Punto::operator = ( const Punto &obj ){

	x = obj.x;
	y = obj.y;

	cout << "Operator = del objeto: " << this << endl;
	return *this;
}

Punto & Punto::operator++ ( void ){ 	//Pre

	this -> x ++;
	if( this -> x == 1920 )
		this -> x = 0;
	this -> y ++;
	if( this -> y == 1080)
		this -> y = 0;

	return *this;
}

Punto Punto::operator ++ ( int ){ 	//Post

	Punto aux(*this); //Esto se le llama constructor de copia, llama al contructor con un objeto de la misma clase.

	this -> x ++;
	if( this -> x == 1920 )
		this -> x = 0;
	this -> y ++;
	if( this -> y == 1080)
		this -> y = 0;

	return aux;
}

Punto operator*( const int &n )const{

    Punto aux( x * n, y * n );
    return aux;

    //return Punto( x * n, y * n );
}

Punto operator * (const int &n,const Punto &obj){  //Es una funcion amiga, por lo tanto no hay objeto this.

    return Punto( obj.x * n, obj.y * n );
}

ostream & operator << ( ostream &sal, const Punto & obj){

    sal << "( " << obj.x << ", " << obj.y << " )";
    return sal;
}

istream & operator >> ( istream &ent, Punto & obj){

    cout << "Coordenada x?: ";
    ent >> obj.x;
    cout << "Coordenada y?: ";
    ent >> obj.y;

    return ent;
}

bool Punto::operator > (const Punto &obj)const{

    return (x * x + y * y) > ( obj.x * obj.x + obj.y * obj.y ) ? true : false;
}

#ifdef DEPURAR
Punto::~Punto(void) {
    cout << "Destructor de " << this << endl;
}
#endif // DEPURAR

