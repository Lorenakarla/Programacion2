#include <iostream>
#include "libro.h"
using namespace std;

int main()
{


char s1[11] = "Hola ";
char s2[6] = "amigo";
printf( "s1=%s\t", s1 );
printf( "s2=%s\n", s2 );
strcat( s1, s2 );
printf( "s1=%s\n", s1 );

    Libro lib1("Programacion C","Brian Kernighan y Dennis Ritchie",294);
    Libro lib2;
    Libro lib3("The c++ programming Languaje","Bjarne Strounstrup",1350);
    Libro lib4 = lib1 + lib3;
    lib1 = lib3 = lib4;
    lib4 = lib2 + lib2;

    if(lib1 == lib2)
        cout << "Iguales" << endl;
    else
        cout << "Distintos" << endl;

    cout<<"El libro lib1 es: " << lib1 << endl;
    cout<<"El libro lib2 es: " << lib2 << endl;
    cout<<"El libro lib3 es: " << lib3 << endl;
    cout<<"El libro lib4 es: " << lib4 << endl;


    return 0;
}
