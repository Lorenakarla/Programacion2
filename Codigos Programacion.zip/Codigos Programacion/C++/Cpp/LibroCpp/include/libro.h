#include<iostream>
#include<string.h>
using namespace std;
class Libro
{
    public:
        Libro(const char* titulo = NULL, const char* autor = NULL, const unsigned int cantPag = 0);
        ~Libro();
        Libro(const Libro& other);


        friend ostream& operator << (ostream&, const Libro&);
        Libro operator + (const Libro&) const;
        Libro& operator = (const Libro&);
        bool operator == (const Libro&) const;


    private:
        char titulo[101];
        char *autor;
        unsigned int cantPag;
};
