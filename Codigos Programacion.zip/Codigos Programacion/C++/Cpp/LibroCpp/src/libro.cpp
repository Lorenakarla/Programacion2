#include "libro.h"

char* duplicarCadena(const char* cad)
{
    if(cad != NULL && *cad != '\0')
    {
        try
        {
            char* ret = new char[strlen(cad)+1];
            strcpy(ret,cad);
            return ret;
        }
        catch(bad_alloc&)
        {
            cerr << "Error de memoria";
        }
    }
    return NULL;
}

Libro::Libro(const char* titulo ,const char* autor ,const unsigned int cantPag ):cantPag(cantPag)
{
    this-> autor = duplicarCadena(autor);
    if(titulo == NULL)
        this->titulo[0] = '\0';
    else
        strncpy(this->titulo,titulo,sizeof(this->titulo)-1);
        this->titulo[sizeof(this->titulo)-1] = '\0';
}
Libro::Libro(const Libro& l)
{
    cantPag = l.cantPag;
    autor = duplicarCadena(l.autor);
    strcpy(titulo,l.titulo);
}
Libro::~Libro()
{
    delete [] autor;
}

ostream& operator << (ostream& sal, const Libro& l){

    sal << "Autor = " << ((l.autor == NULL)? "-": l.autor) << endl;
    sal << " Titulo= " << l.titulo;
    sal << " Cant Pag = " << l.cantPag;
    return sal;
}

Libro Libro:: operator + (const Libro& l) const{
    if(strcmp(this->titulo, l.titulo) != 0)
    {
        char* auxTitulo, *auxAutor;

        auxTitulo = new char[strlen(l.titulo)+strlen(titulo)+2];
        strcpy(auxTitulo,titulo);
        strcat(auxTitulo," ");
        strcat(auxTitulo,l.titulo);

        auxAutor = new char[strlen(l.autor)+strlen(autor)+2];
        strcpy(auxAutor,autor);
        strcat(auxAutor," ");
        strcat(auxAutor,l.autor);

        return Libro(auxTitulo,auxAutor, l.cantPag + cantPag);
    }
    return Libro(titulo,autor,l.cantPag+cantPag);
}

Libro& Libro::operator = (const Libro& l){
    cantPag = l.cantPag;
    delete [] autor;
    autor = duplicarCadena(l.autor);
    strcpy(titulo,l.titulo);
    return *this;
}

bool Libro::operator == (const Libro& l) const{
        return cantPag == l.cantPag && !strcmp(titulo,l.titulo) && !strcmp(autor,l.autor);
}

