#include "Distancia.h"
#include <iomanip>

const int Distancia::metros=1;
const int Distancia::kilometros=2;
const int Distancia::yardas=3;
const int Distancia::pulgadas=4;

Distancia::Distancia(double distancia, int unidad){
    valor=distancia;
    this->unidad=unidad;
}

float Distancia::getConversion(int unidad){
    switch(unidad){
    case kilometros:
        return 0.001;
    case yardas:
        return 1.09361;
    case pulgadas:
        return 39.3701;
    default:
        return 1;
    }
}

ostream& operator<<(ostream &sal, const Distancia &dist){
    sal << setprecision(4) << fixed << dist.valor;
    switch(dist.unidad){
    case Distancia::metros:
        sal << "m";
        break;
    case Distancia::kilometros:
        sal << "km";
        break;
    case Distancia::yardas:
        sal << "yardas";
        break;
    case Distancia::pulgadas:
        sal << "pulgadas";
    }
    return sal;
}

Distancia Distancia::operator+(const Distancia &dist)const{
    double resultado = valor + dist.valor*getConversion(unidad)/getConversion(dist.unidad); //Dividiendo paso a metros y multiplicando a la nueva unidad
    return Distancia(resultado, unidad);
}
Distancia operator+(double n, const Distancia &dist){
    return Distancia(dist.valor + n*Distancia::getConversion(dist.unidad), dist.unidad);
}
bool Distancia::operator>=(const Distancia &dist)const{
    return valor>=dist.valor*getConversion(unidad)/getConversion(dist.unidad);
}
void Distancia::convertir(int unidad){
    valor=valor*getConversion(unidad)/getConversion(this->unidad);
    this->unidad=unidad;
}
Distancia& Distancia::operator+=(const Distancia &dist){
    valor+=dist.valor*getConversion(unidad)/getConversion(dist.unidad);
    return *this;
}
