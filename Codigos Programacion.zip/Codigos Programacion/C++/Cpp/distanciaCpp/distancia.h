#ifndef DISTANCIA_H_INCLUDED
#define DISTANCIA_H_INCLUDED

#include <iostream>

using namespace std;

class Distancia{
private:
    double valor;
    int unidad;
public:
    static const int metros;
    static const int kilometros;
    static const int yardas;
    static const int pulgadas;

    Distancia(double distancia=0, int unidad=metros);

    static float getConversion(int unidad);
    friend ostream& operator<<(ostream &sal, const Distancia &dist);
    Distancia operator+(const Distancia &dist)const;
    friend Distancia operator+(double n, const Distancia &dist);
    bool operator>=(const Distancia &dist)const;
    void convertir(int unidad);
    Distancia& operator+=(const Distancia &dist);
};

#endif // DISTANCIA_H_INCLUDED
