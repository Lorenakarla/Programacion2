#include <iostream>
#include "Distancia.h"

using namespace std;

int main()
{
    /*
    *1m=0.001km
    *1m=1.09361y
    *1m=39.3701p
    */
    Distancia d1, d2(3500.30), d3(2000.00, Distancia::kilometros);

    cout << "D1:" << d1 << " D2: " << d2 << " D3: " << d3 << endl;
    cout << "El valor de la suma es: " << (d3 + d2) << endl;
    d1=222.30+d3;
    cout << "El valor de la suma es D1: " << d1 << endl;
    if(d1>=d3)
        cout << "D1 es mayor o igual a D3" << endl;
    else
        cout << "D1 es menor que D3" << endl;
    d3.convertir(Distancia::pulgadas);
    d3+=d2;
    cout << "El valor de la suma es: " << d3 << endl;
    d1.convertir(Distancia::yardas);
    cout << "El valor de d1 es: " << d1 << endl;
    return 0;
}

/*
Les dejo mi c�digo del parcial de hoy (5/7/2016 Ma-Vi tarde) de la parte de C++.
Hab�a que codificar para que funcione el siguiente main. Por redondeo me quedaron algunos n�meros un poquito distintos (no tengo foto de c�mo ten�a que quedar).
*/
