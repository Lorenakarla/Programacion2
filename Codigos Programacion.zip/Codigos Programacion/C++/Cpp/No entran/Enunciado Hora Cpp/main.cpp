#include "Hora.h"

using namespace std;

int main()
{
    Hora h1(23,58,0),h2(2,3,4),h3,h4,h5(23,59,59);

    h3 = h1 + 122;
    cout << h5 << " ";
    ++h5;
    cout << h5 << " ";
    ++h5;
    h5.mostrar();
    cout<<endl;
    h3.mostrar();
    cout<< "  " <<h3 << " " << endl;
    ++h4;
    h4.mostrar();
    h4--;
    cout <<endl << h4 << " ";
    h4.mostrar();
    h4--;
    cout <<endl << h4 << " ";
    h4.mostrar();
    return 0;
}
