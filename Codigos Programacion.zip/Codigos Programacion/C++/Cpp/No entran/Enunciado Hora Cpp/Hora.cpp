#include "Hora.h"
Hora::Hora(const int hora,const int minutos,const int segundos){
   this->segundos = hora*3600+minutos*60+segundos;
}
Hora::Hora(const Hora& other)
{
    segundos = other.segundos;
}
int Hora::Getsegundos()const{ return segundos; }
void Hora::Setsegundos(int val) { segundos = val; }

Hora& Hora::operator = (const Hora& obj){
    segundos = obj.segundos;
    return *this;
}
Hora Hora::operator + (const int seg)const{
        int s = seg + segundos;
        while(s>=86400)
            s-=86400;
        return Hora(0,0,s);
}
Hora& Hora::operator ++ (){
        segundos++;
        if(segundos>=86400)
            segundos -= 86400;
        return *this;
}
int operator - (const int seg, const Hora& o){
    return 1;
}
Hora& Hora::operator --(){
    segundos--;
    if(segundos==0)
            segundos = 86399;
    else
        segundos--;
    return *this;
}
Hora Hora :: operator --(int){
    Hora aux(*this);
    if(segundos==0)
            segundos = 86399;
    else
        segundos--;
    return aux;
}
ostream& operator << (ostream& o, const Hora& hs){
   int h=0,s=0,m=0;
   hs.convertSToHora(h,m,s);
   if(h>=12)
        o << h - 12 << ":" << m << ":" << s << "pm";
    else
        o << h << ":" << m << ":" << s << "am";
    return o;
}
void Hora::convertSToHora(int&h,int&m,int&s)const
{
    Hora aux(*this);
    while(aux.segundos>=3600){
        h++;
        aux.segundos-=3600;
    }
    while(aux.segundos>=60){
        m++;
        aux.segundos-=60;
    }
    s = aux.segundos;
}
void Hora::mostrar(){
   int h=0,s=0,m=0;
   convertSToHora(h,m,s);
   cout << h << ":" << m << ":" << s;
}
