#include<iostream>
using namespace std;
class Hora
{
    public:
        Hora(const int hora=0,const int minutos=0,const int segundos=0);
        Hora(const Hora& other);

        int Getsegundos()const;
        void Setsegundos(int val);

        Hora& operator = (const Hora&);
        Hora  operator + (const int) const;
        Hora& operator ++ ();
        friend int operator - (const int, const Hora&);
        Hora& operator --();
        Hora operator --(int);


        friend ostream& operator << (ostream&, const Hora&);

        void mostrar();

    private:
        int segundos;
        void convertSToHora(int&h,int&m,int&s)const;
};
