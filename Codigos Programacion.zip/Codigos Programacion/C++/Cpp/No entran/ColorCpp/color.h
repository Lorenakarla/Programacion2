#ifndef COLOR_H_INCLUDED
#define COLOR_H_INCLUDED

#include<string.h>
#include<iostream>
using namespace std;
class Color
{
    public:
        Color(const int r=0, const int g=0, const int b=0,
              const char* nombr = NULL);
        Color(const Color&);
        ~Color();

        Color& operator = (const Color&);
        Color operator -- (int);
        Color& operator ++ ();
        Color operator ++ (int);

        void cambiarColorNomb(const char*);

        friend ostream& operator << (ostream&, const Color&);

    //protected:
    private:
        int r;
        int g;
        int b;
        char *colorNomb;
};

#endif // COLOR_H_INCLUDED
