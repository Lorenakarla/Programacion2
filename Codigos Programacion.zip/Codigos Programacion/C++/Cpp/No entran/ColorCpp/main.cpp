#include <iostream>
#include "Color.h"
using namespace std;

int main()
{
    Color c1(255,0,0,"Rojo Pleno"),c2,c3;

    c2 = c1--;
    c3 = ++c2;
    Color c4 = c3++;
    c4.cambiarColorNomb("Amarillo patito");
    cout << c1 << c2 << c3 << (c4 = c3) << endl;
    return 0;
}


///NOTA:COMO LA CONSIGNA DICE DECREMENTAR SI SE PUEDE
///DECIDI TOMAR QUE SE CONSERVA LOS VALORES DE LOS ENTEROS
///QUE DEJEN DE PERTENECER A LOS INTERVALOS.
///NO LO IMPLEMENTE CIRCULAR POR CUESTION DE QUE PLANTIE
///EL EJERCICIO DE ESTA MANERA DESDE UN PRINCIPIO
///DE TODAS FORMAS EN LOS INCREMENTOS DESPUES
///DE LOS IF QUE VALIDAN POR EJEMPLO
/// if(r<255)
///     r++;
///DEBERIA PONER ELSE r=0 Y ASI POR CADA COLOR;
