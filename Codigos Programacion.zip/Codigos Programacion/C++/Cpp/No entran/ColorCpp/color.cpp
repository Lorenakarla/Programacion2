#include "Color.h"
char* duplicarCadena(const char*cad)
{
    if(cad != NULL && cad != '\0')
    {
        try
        {
            char* aux = new char[strlen(cad)+1];
            strcpy(aux,cad);
            return aux;
        }
        catch(bad_alloc&)
        {
            cerr<<"Error";
        }
    }
    return NULL;
}
Color::Color(const int r, const int g, const int b, const char* nombr)
{
    if(!(r>=0&&r<=255) || !(g>=0&&g<=255) || !(b>=0&&b<=255) ){
        cout << "Color fuera de rango";
        this->r =0;
        this->g =0;
        this->b = 0;
    }
    else
    {
        this->r = r;
        this->b = b;
        this->g = g;
        if(nombr != NULL && nombr != '\0')
        {
            try
            {
                colorNomb = new char[strlen(nombr)+1];
                strcpy(colorNomb,nombr);
            }
            catch(bad_alloc&)
            {
                cerr<<"Error";
            }
        }
    }
}
Color::Color(const Color& c):r(r),g(g),b(b)
{
    colorNomb = duplicarCadena(c.colorNomb);
}
Color::~Color()
{
    delete [] colorNomb;
}
ostream& operator << (ostream&o, const Color&c)
{
    o<<"r:"<<c.r<<" g:"<<c.g<<" b:"<<c.b<<" nombre= "<<((c.colorNomb!=NULL)?c.colorNomb:"-")<<endl;
    return o;
}
Color& Color:: operator = (const Color&c)
{
    r = c.r;
    g = c.g;
    b = c.b;
    delete[]colorNomb;
    colorNomb = duplicarCadena(c.colorNomb);
    return *this;
}
Color Color :: operator --(int)
{
    Color c(r,g,b,colorNomb);
    if(r>0)
        r--;
    if(g>0)
        g--;
    if(b>0)
        b--;
    return c;
}

Color Color :: operator ++(int)
{
    Color c(r,g,b,colorNomb);
    if(r<255)
        r++;
    if(g<255)
        g++;
    if(b<255)
        b++;
    return c;
}

Color& Color:: operator ++ ()
{
    if(r<255)
        r++;
    if(g<255)
        g++;
    if(b<255)
        b++;
    return *this;
}

void Color::cambiarColorNomb(const char*newName)
{
        delete[]colorNomb;
        colorNomb = duplicarCadena(newName);
}
