#ifndef MAINEMPLE_H_
#define MAINEMPLE_H_

#include <iostream>

#include "persona.h"
#include "empleado.h"

using namespace std;


#endif

