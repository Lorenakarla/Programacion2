
#include "main.h"
#include "persona.h"

using namespace std;

int main()
{
    Persona     p1,
                p2;

    cout << "Mostrando p1:" << endl << p1 << endl
         << "Mostrando p2:" << endl << p2 << endl;

    cout << "p1 y p2 son " << (p1 != p2 ? "distintos" : "iguales") << endl;

    Persona     p3(22333444L, "Sa", "Leo", 'M'),
                p4(11222333L, "Sa", "Lia", 'F'),
                p5(p3);

    p1 = p2 = p5;
    cout << "Ingresando p2:" << endl;
    cin >> p2;

    cout << "Mostrando p1:" << endl << p1 << endl
         << "Mostrando p2:" << endl << p2 << endl
         << "A los que se les asigno p5:" << endl << p5 << endl;

    return 0;
}
