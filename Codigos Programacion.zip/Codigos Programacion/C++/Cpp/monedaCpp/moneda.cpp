#include "moneda.h"

string Moneda::simboloAr="AR$";
string Moneda::simboloUsd="US$";
string Moneda::simboloRs="R$";
string Moneda::simboloUyu="UY$";

float Moneda::valorAr=1;
float Moneda::valorUsd=1;
float Moneda::valorRs=1;
float Moneda::valorUyu=1;

Moneda::Moneda(float valor, int tipo){
    this->tipo=tipo;
    this->valor=valor;
}

void Moneda::convertir(int tipo){
    valor=valor*getValorMoneda(this->tipo)/getValorMoneda(tipo); //Multiplicando lo paso a pesos y dividiendo al nuevo tipo
    this->tipo=tipo;
}

float Moneda::getValor()const{
    return valor;
}

float Moneda::getValor(int tipo)const{
    if(tipo==this->tipo)
        return valor;
    return valor*getValorMoneda(this->tipo)/getValorMoneda(tipo);
}

void Moneda::setValorMoneda(int tipo, float valor){
    switch(tipo){
    case MONEDA_usd:
        valorUsd=valor;
    case MONEDA_rs:
        valorRs=valor;
    case MONEDA_uyu:
        valorUyu=valor;
    }
}

float Moneda::getValorMoneda(int tipo){
    switch(tipo){
    case MONEDA_ar:
        return valorAr;
    case MONEDA_usd:
        return valorUsd;
    case MONEDA_rs:
        return valorRs;
    case MONEDA_uyu:
        return valorUyu;
    }
    return 0;
}

void Moneda::setSimbolo(int tipo, const char *simbolo){
    switch(tipo){
    case MONEDA_ar:
        simboloAr=simbolo;
    case MONEDA_usd:
        simboloUsd=simbolo;
    case MONEDA_rs:
        simboloRs=simbolo;
    case MONEDA_uyu:
        simboloUyu=simbolo;
    }
}

string Moneda::getSimbolo(int tipo){
    switch(tipo){
    case MONEDA_ar:
        return simboloAr;
    case MONEDA_usd:
        return simboloUsd;
    case MONEDA_rs:
        return simboloRs;
    case MONEDA_uyu:
        return simboloUyu;
    }
    return "";
}

ostream& operator<<(ostream &sal, const Moneda &money){
    sal.setf(ios::fixed); //Estas dos las copie del modelo de Producto y Bulto
    sal.precision(2); //Entre las dos hacen que muestre siempre dos decimales
    sal << Moneda::getSimbolo(money.tipo) << " " << money.getValor();
    return sal;
}

Moneda Moneda::operator+(const Moneda &mon)const{
    return Moneda(valor + mon.getValor(tipo),tipo);
}

Moneda operator+(int x, const Moneda &mon){
    return Moneda(mon.getValor()+x/Moneda::getValorMoneda(mon.tipo),mon.tipo);
}

bool Moneda::operator>=(const Moneda &mon)const{
    return valor >= mon.getValor(tipo);
}

void Moneda::operator+=(const Moneda &mon){
    valor+=mon.getValor(tipo);
}
