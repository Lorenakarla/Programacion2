#ifndef MONEDA_H_INCLUDED
#define MONEDA_H_INCLUDED

#include <string>
#include <iostream>

using namespace std;

#define MONEDA_ar 0
#define MONEDA_usd 1
#define MONEDA_rs 2
#define MONEDA_uyu 3

class Moneda{
private:
    int tipo;
    float valor;

    static string simboloAr;
    static string simboloUsd;
    static string simboloRs;
    static string simboloUyu;

    static float valorAr;
    static float valorUsd;
    static float valorRs;
    static float valorUyu;
public:
    Moneda(float valor=0, int tipo=MONEDA_ar);
    void convertir(int tipo);
    float getValor()const;
    float getValor(int tipo)const;

    static void setValorMoneda(int tipo, float valor);
    static float getValorMoneda(int tipo);
    static void setSimbolo(int tipo, const char *simbolo);
    static string getSimbolo(int tipo);

    friend ostream& operator<<(ostream &sal, const Moneda &money);
    Moneda operator+(const Moneda &mon)const;
    friend Moneda operator+(int x, const Moneda &mon);
    bool operator>=(const Moneda &mon)const;
    void operator+=(const Moneda &mon);
};

#endif // MONEDA_H_INCLUDED
