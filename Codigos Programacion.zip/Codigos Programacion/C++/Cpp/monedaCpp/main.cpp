#include <iostream>
#include "moneda.h"

using namespace std;

int main()
{
    Moneda::setValorMoneda(MONEDA_usd, 9.675);///Dolares
    Moneda::setValorMoneda(MONEDA_rs, 3.707);///Reales
    Moneda::setValorMoneda(MONEDA_uyu, 0.327);///Pesos Uruguayos
    Moneda m1, m2(3500.30), m3(2000.00, MONEDA_usd);
    cout << "M1: " << m1 << " M2: " << m2 << " M3: " << m3<<endl;
    cout << "El valor de la suma es: " << m3 + m2 << endl;
    m1 = 222.30 + m3; ///La constante representa el valor en pesos argentinos
    cout << "El valor de la suma es M1: " << m1 << endl;
    if (m1>=m3)
        cout<<"M1 es mayor o igual a M3"<<endl;
    else
        cout<<"M1 es menor o igual a M3"<<endl;
    m3.convertir(MONEDA_uyu);
    m3 += m2;
    cout << "El valor de la suma es: " << m2 << endl;
    m1.convertir(MONEDA_rs);
    cout << "Antes de cambiar el simbolo: " << m1 << endl;
    Moneda::setSimbolo(MONEDA_rs, "Reales");
    cout << "Despues de cambiar el simbolo: " << m1 << endl;

    return 0;
}
