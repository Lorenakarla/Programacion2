#ifndef CADENA_H_INCLUDED
#define CADENA_H_INCLUDED
#include <iostream>
#include <string.h>

using namespace std;

class Cadena {

private:

    char * cad;

public:

    Cadena( const char *cad = NULL );
    Cadena( const Cadena &obj );
    ~Cadena( void );
    friend ostream & operator <<( ostream & sal,const Cadena & obj );
    friend istream & operator >>( istream & ent, Cadena & obj );
    Cadena &operator = (const Cadena & cad);
    Cadena &operator = (const char * s);
    Cadena &operator =  (const char c);
    Cadena &operator += (const Cadena & obj);
    Cadena &operator += (const char * s);
    Cadena &operator + (const Cadena & obj)const;
    Cadena &operator + (const char * s);
    friend Cadena operator + (const char *s, const Cadena &obj);
    bool operator < (const Cadena & obj)const;
    bool operator < (const char * s)const;
    friend bool operator < (const char * s, const Cadena & obj);
    Cadena operator + (int n)const;
    Cadena operator + (char c)const;

};

char * duplicarCadena( const char * );
char * concatenarCadena( const char *s1, const char *s2 );

#endif // CADENA_H_INCLUDED
