#include "cadena.h"

using namespace std;

int main()
{
    Cadena c1("Hola");







    return 0;
}
