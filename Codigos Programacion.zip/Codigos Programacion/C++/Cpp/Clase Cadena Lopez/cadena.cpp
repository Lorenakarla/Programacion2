#include "cadena.h"

using namespace std;

Cadena::Cadena(const char *s){

    this->cad = duplicarCadena(s);
    ///Control de da�os
    if( s && *s && cad == NULL )
        cerr << "SIN MEMORIA - parametrizado." << endl;
}

Cadena::Cadena( const Cadena & obj ){

    this->cad = duplicarCadena(obj.cad);
    ///Control de da�os
    if( obj.cad && this->cad == NULL )
        cerr << "SIN MEMORIA - de copia." << endl;
}

Cadena::~Cadena( void ){

    delete[]cad; //delete[]this->cad;
}

Cadena & Cadena::operator = (const char * cad){

    delete[]this->cad;
    this->cad = duplicarCadena(cad);
    ///Control de da�os
    if( cad && this->cad == NULL )
        cerr << "SIN MEMORIA - de copia." << endl;

    return *this;
}

Cadena & Cadena::operator = (char c){

    delete[]this->cad;
    char auxC[2];
    auxC[0] = c;
    auxC[1] = '\0';

    this->cad = duplicarCadena(auxC);
    ///Control de da�os
    if( auxC == NULL && c != '\0' )
        cerr << "SIN MEMORIA - operator =(char c)" << endl;

    return *this;
}

istream & operator >> (istream & ent, Cadena & obj){

    delete[]obj.cad;
    char cad[5000];
    ent.get(cad, sizeof(cad), '\n'); ///ent es la mismo que cin porque es una referencia.

    ent.ignore(5000,'\n');
    obj.cad = duplicarCadena(cad);
    ///Control de da�os
    if( cad[0] && obj.cad == NULL )
        cerr << "SIN MEMORIA - operator >> " << endl;

    return ent;
}



/**-------------------------------------------------------------

inline void Flush( STD::istream &e ){

    e.clear();
    e.sync();
}

-------------------------------------------------------------**/

char * duplicarCadena( const char * s ){

    if( s && *s ){

        char * aux = new char[strlen(s)+1];
        strcpy(aux, s);
        return aux;
    }
    return NULL;
}

/**
char * duplicarCadena( const char * s ){

    if( s && *s ){

        try{
            char * aux = new char[strlen(s)+1];
            strcpy(aux, s);
            return aux;
        }

        catch( std::bad_alloc & ){

            ///Codigo de la exepcion.
        }
    }
    return NULL;
}
**/

char * concatenarCadena( const char *s1, const char *s2 ){

    int tam1 = s1 ? strlen(s1) : 0;
    int tam2 = s2 ? strlen(s2) : 0;

    if( tam1 || tam2 ){

        char * aux = new char[tam1 + tam2 + 1];
        *aux = '\0';
        if( tam1 )
            strcat(aux, s1);
        if( tam2 )
            strcat(aux, s2);

       return aux;
    }

    return NULL;
}
