#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

#define AN_BASE 1600
#define AN_TOPE 2100

typedef struct
{
    int di,
        me,
        an;
}tFecha;

void imprimirFecha( const tFecha * );
int esBisiesto( int );
int ingresarFecha( tFecha * );
int esFechaValida( tFecha * );
int ingresarFechaValida( tFecha *);
int aJuliano( const tFecha *);
int compararFecha( const tFecha *, const tFecha *);
int diasEntreDosfechas( const tFecha *, const tFecha * );
int calcularDiasEntreFechas( const tFecha *, const tFecha * );


#endif // FECHA_H_INCLUDED
