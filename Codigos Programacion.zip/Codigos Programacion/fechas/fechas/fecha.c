#include "fecha.h"

void imprimirFecha( const tFecha * fecha )
{
    printf("\nLa fecha es: %d / %d / %d", fecha->di, fecha->me, fecha->an);
}

int esBisiesto( int an )
{
    return (an % 4 == 0 && an % 100 != 0) || an % 400 == 0;
}

int esFechaValida( tFecha *fec )
{
    static char dias[][12] = { {31,28,31,30,31,30,31,31,30,31,30,31},
                               {31,29,31,30,31,30,31,31,30,31,30,31} };

    return fec->me >= 1 && fec->me <= 12 &&
           fec->an >= AN_BASE && fec->an <= AN_TOPE &&
           fec->di >= 1 && fec->di <= dias[esBisiesto(fec->an)][fec->me-1];
}

int ingresarFechaValida( tFecha *fecha )
{
    while( !ingresarFecha( fecha ) || !esFechaValida( fecha ) )
    {
        printf("Ingrese de nuevo la fecha: ");
    }

    return 1;
}

int ingresarFecha( tFecha *fec )
{
    printf("\nIngrese el anio: ");
    scanf("%d", &fec->an);
    printf("Ingrese el mes: ");
    scanf("%d", &fec->me);
    printf("Ingrese el dia: ");
    scanf("%d", &fec->di);

    return fec->di && fec->me && fec->an;
}

int aJuliano( const tFecha *fec)
{
    static short int dias[][12] = { {0,31,59,90,120,151,181,212,243,273,304,334},
                                    {0,31,60,91,121,152,182,213,244,274,305,335} };

    return fec->di + dias[esBisiesto(fec->an)][fec->me-1];
}

int compararFecha( const tFecha *f1, const tFecha *f2)
{
     int cmp = f1->an - f2->an;
     if( cmp )
        return cmp;
     cmp = f1->me - f2->me;
     if( cmp )
        return cmp;
     return f1->di - f2->di;
}

int diasEntreDosfechas( const tFecha *fMenor, const tFecha *fMayor )
{
    int acum = -aJuliano( fMenor ) + aJuliano( fMayor ),
        ciclo = fMenor->an;

    while( ciclo < fMayor->an )
    {
        acum += 365 + esBisiesto(ciclo);
        ciclo++;
    }

    return acum;
}

int calcularDiasEntreFechas( const tFecha *f1, const tFecha *f2 )
{
    int cmp = compararFecha( f1, f2 );
    if( cmp == 0 )
        return 0;
    if( cmp < 0 )
        return diasEntreDosfechas( f1, f2 );
    else
        return diasEntreDosfechas( f2, f1 );
}
