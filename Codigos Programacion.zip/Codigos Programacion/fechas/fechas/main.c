#include "fecha.h"

int main()
{

    tFecha fecha1;
    tFecha fecha2;
    int dias;
    int diferencia;

    ingresarFechaValida( &fecha1 );
    ingresarFechaValida( &fecha2 );
    imprimirFecha( &fecha1 );
    imprimirFecha( &fecha2 );

    ///dias = aJuliano( &fecha1 );
    ///printf("\nLa cantidad de dias es: %d", dias);

    if( compararFecha(&fecha1, &fecha2) > 0 )
        printf("\n\nEs mas grande la fecha 1");
    else if( compararFecha(&fecha1, &fecha2) < 0 )
        printf("\n\nEs mas grande la fecha 2");
    else
        printf("\n\nSon iguales.");

    if( compararFecha(&fecha1, &fecha2) > 0 )
        diferencia = diasEntreDosfechas(&fecha2, &fecha1);
    else
        diferencia = diasEntreDosfechas(&fecha1, &fecha2);
    printf("\nLa cantidad de dias entre las dos fechas son: %d", diferencia);

    return 0;
}
