#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 30
#define TODO_MAL 1

typedef struct
{
    int dni;
    char apellido[TAM];
    char nombre[TAM];
    double sueldo;
}t_empleado;

typedef struct
{
    int dni;
    char apellido[TAM];
    char nombre[TAM];
    float promedio;
}t_estudiante;
