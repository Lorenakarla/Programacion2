#include "funciones.h"

int main()
{
    FILE *fpEst, *fpEmple;
    t_empleado empleado;
    t_estudiante estudiante;
    int CompNomb, CompApe;

    /* creo el lote de pruebas */

    t_empleado emple[3] = {{11222333, "lopez", "mario", 10000},{12345678, "ma", "lia", 10000}, {11111111, "rodriguez", "maria julia", 10000}};
    t_estudiante estu[3] = {{11222333, "lopez", "mario", 6.90}, { 22222222, "martinez", "emilia", 7.90 }, {11111111, "rodriguez", "maria julia", 7.24}};
    fpEmple = fopen("empleados.bin", "wb");
    if(fpEmple == NULL)
        return TODO_MAL;
    fpEst = fopen("estudiantes.bin", "wb");
    if(fpEst == NULL)
    {
        fclose(fpEmple);
        return TODO_MAL;
    }
    fwrite(emple, sizeof(emple), 1, fpEmple);
    fwrite(estu, sizeof(estu), 1, fpEst);

    fclose(fpEmple);
    fclose(fpEst);



    /* empiezo el ejercicio */

    fpEmple = fopen("empleados.bin", "r+b");
    if(fpEmple == NULL)
        return TODO_MAL;
    fpEst = fopen("estudiantes.bin", "rb");
    if(fpEst == NULL)
    {
        fclose(fpEmple);
        return TODO_MAL;
    }
    fread(&empleado, sizeof(empleado), 1, fpEmple);
    fread(&estudiante, sizeof(estudiante), 1, fpEst);
    while(!feof(fpEmple) && !feof(fpEst))
    {
        CompNomb = stricmp(empleado.nombre, estudiante.nombre);
        CompApe = stricmp(empleado.apellido, estudiante.apellido);
        if(estudiante.promedio >=7 && CompApe==0 && CompNomb == 0 && empleado.dni == estudiante.dni)
        {
            empleado.sueldo*=1.0728;
            fseek(fpEmple, -sizeof(t_empleado), SEEK_CUR);
            fwrite(&empleado, sizeof(empleado), 1, fpEmple);
            fseek(fpEmple, 0, SEEK_CUR);
            fread(&empleado, sizeof(empleado), 1, fpEmple);
            fread(&estudiante, sizeof(estudiante), 1, fpEst);
        }
        else if(estudiante.promedio < 7)
            fread(&estudiante, sizeof(estudiante), 1, fpEst);
        else
        {
            if(CompApe > 0)
                fread(&estudiante, sizeof(estudiante), 1, fpEst);
            else if(CompApe < 0)
                fread(&empleado, sizeof(empleado), 1, fpEmple);
            else
            {
                if(CompNomb > 0)
                    fread(&estudiante, sizeof(estudiante), 1, fpEst);
                else if(CompNomb < 0)
                    fread(&empleado, sizeof(empleado), 1, fpEmple);
                else
                {
                    if(empleado.dni > estudiante.dni)
                        fread(&estudiante, sizeof(estudiante), 1, fpEst);
                    else
                        fread(&empleado, sizeof(empleado), 1, fpEmple);
                }
            }
        }

    }
    fclose(fpEmple);
    fclose(fpEst);

    printf("el sueldo de maria julia es %lf", empleado.sueldo);



    return 0;
}
