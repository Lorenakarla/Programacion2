#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char *str_chr(const char *, int);
