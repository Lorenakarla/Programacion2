#include "funciones.h"
char *str_chr(const char *cad, int car)
{
    while(*cad && *cad !=car)
        cad++;
    return *cad == car ? (char *)cad : NULL;
}
