#include "funciones.h"

int main()
{
    char cad[12] = "Hola amigos";
    char car = 'a';
    printf( "cadena = %s \t", cad );
    printf( "char = %c \n", car );
    printf( "str_chr = %s \n", str_chr( cad, car ) );
    return 0;
}
