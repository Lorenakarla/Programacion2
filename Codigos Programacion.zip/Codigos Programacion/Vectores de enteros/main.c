#include "funciones.h"

int main()
{
    int vector[TAM];
    int PrimLibre=0;
    int Ocurrencia;
    CargarVector(vector, &PrimLibre);
    MostrarVector(vector, &PrimLibre);
    printf("ingrese la Ocurrencia a eliminar: \n");
    scanf("%d", &Ocurrencia);
    printf("se encontraron %d duplicados \n", EliminarDuplicados(vector, &PrimLibre, Ocurrencia));
    MostrarVector(vector, &PrimLibre);


    return 0;
}
