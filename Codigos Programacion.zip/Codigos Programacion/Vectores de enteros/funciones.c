#include "funciones.h"

int CargarVector(int *vec, int *PrimLibre)
{
    int i = 0;
    do
    {
        printf("ingrese valor (0 para salir): \n");
        scanf("%d", vec);
        if(*vec == 0)
            return 0;
        vec++;
        i++;
        (*PrimLibre)++;
    }while(i<TAM);
    return 1;
}

int  EliminarOcurrencia(int *vec, int *PrimLibre, int ocurrencia)
{
    int i=0;
    while(i < *PrimLibre && *vec != ocurrencia)
    {
        vec++;
        i++;
    }
    if(i >= *PrimLibre)
        return 0;
    while(i < (*PrimLibre)-1)
    {
        *vec = *(vec+1);
        vec++;
        i++;
    }
    (*PrimLibre)--;
    return 1;
}

void MostrarVector(int *vec, int *PrimLibre)
{
    int i;
    for(i=0; i< *PrimLibre; i++)
    {
        printf("Vector[%d]= %d \t",i , *vec);
        vec++;
    }
    printf("\n");
}


int EliminarDuplicados(int *vec, int *PrimLibre, int ocurrencia)
{
    int *escritura = vec;
    int i=0, cont=0, aux=*PrimLibre;
    while(i < *PrimLibre)
    {
        if(*vec != ocurrencia)
        {
            *escritura = *vec;
            escritura++;
            cont++;
        }
        vec++;
        i++;

    }
    (*PrimLibre) = cont;
    return aux-cont;

}
