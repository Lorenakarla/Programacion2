#include <stdio.h>
#include <stdlib.h>
#define TAM 8

int EliminarOcurrencia(int *, int *, int);
void MostrarVector(int *, int *);
int CargarVector(int *, int *);
int EliminarDuplicados(int *, int *, int);
