#include "funciones.h"

int main()
{
    t_info info;
    t_lista lista;
    crearlista(&lista);
    while(!ListaLlena(&lista)&&Ingresar(&info))
    {
        InsertarListaDoble(&lista, &info);
    }
    printf("se eliminaron %d elementos de la lista\n", eliminarUnicos(&lista));
    while(!ListaVacia(&lista))
    {
        SacarDeLista(&lista, &info);
        Mostrar(&info);
    }

    return 0;
}
