#include "funciones.h"

void crearlista(t_lista *lista)
{
    *lista = NULL;
}

int InsertarListaDoble(t_lista *lista, t_info *info)
{
    t_nodo *anterior = NULL, *siguiente = NULL, *aux = *lista;
    int cmp;
    if(aux)
    {
        while(aux->sig && comparar(info , &aux->info)>0)
            aux = aux->sig;
        while(aux->ant && comparar(info, &aux->info)<0)
            aux = aux->ant;

        if((cmp=comparar(info, &aux->info))>0)
        {
            anterior = aux;
            siguiente = aux->sig;
        }
        else if(cmp<0)
        {
            anterior = aux->ant;
            siguiente = aux;
        }
        else
        {
            pisar(info, &aux->info);
            return 1;
        }
    }
    t_nodo *nue = (t_nodo *)malloc(sizeof(t_nodo));
    if(nue == NULL)
        return 0;
    nue->info = *info;
    nue->sig = siguiente;
    nue->ant = anterior;
    if(anterior)
        anterior->sig = nue;
    if(siguiente)
        siguiente->ant = nue;
    *lista = nue;
    return 1;
}
int comparar(t_info *d1, t_info *d2)
{
    return d1->clave - d2->clave;
}
void pisar(t_info *d1, t_info *d2)
{
    d2->clave = d1->clave;
}

int ListaLlena(t_lista *lista)
{
    t_nodo *aux = (t_nodo *)malloc(sizeof(t_nodo));
    free(aux);
    return aux == NULL ? 1:0;
}

int Ingresar(t_info *info)
{
    do
    {
        printf("ingrese clave: ");
        scanf("%d", &info->clave);
        if(info->clave == 0)
            return 0;
    }while(info->clave < 0);
    return 1;
}

void Mostrar(t_info *info)
{
    printf("%d\n", info->clave);
}


int SacarDeLista(t_lista *lista, t_info *info)
{
    if(*lista == NULL)
        return 0;
    t_nodo *anterior , *siguiente , *aux = *lista;
    *info = aux->info;
    if(aux->sig)
        *lista = aux->sig;
    else if(aux->ant)
        *lista = aux->ant;
    else
        *lista = NULL;
    anterior = aux->ant;
    siguiente = aux->sig;
    free(aux);
    if(anterior)
        anterior->sig = siguiente;
    if(siguiente)
        siguiente->ant = anterior;
    return 1;
}
int VaciarLista(t_lista *lista)
{
    t_nodo *anterior , *siguiente , *aux;
    while(*lista)
    {
        aux = *lista;
        if(aux->sig)
            *lista = aux->sig;
        else if(aux->ant)
            *lista = aux->ant;
        else
            *lista = NULL;
        anterior = aux->ant;
        siguiente = aux->sig;
        free(aux);
        if(anterior)
            anterior->sig = siguiente;
        if(siguiente)
            siguiente->ant = anterior;
    }
    return 1;

}


void OrdenarLista(t_lista *lista)
{
    t_nodo *inicio= *lista, *q, *sig , *sigsig, *anterior;
    int marca=1;
    while(inicio->ant)
        inicio = inicio->ant;
    if(*lista)
    {
        while(marca)
        {
            marca = 0;
            q = inicio;
            while(q->sig)
            {
                if(comparar(&q->info, &q->sig->info)>0)
                {
                    marca = 1;
                    anterior = q->ant;
                    sig = q->sig;
                    sigsig = sig->sig;

                    sig->ant = anterior;
                    q->ant = sig;
                    q->sig = sigsig;
                    sig->sig = q;
                    if(sigsig)
                        sigsig->ant = q;
                    if(anterior)
                        anterior->sig = sig;
                }
                else
                    q = q->sig;
            }
        }
    }
}
int ListaVacia(t_lista *lista)
{
    if(*lista == NULL)
        return 1;
    else
        return 0;
}



int eliminarDuplicadosNoOrdenada(t_lista *p)
{
    t_nodo *aux, *act = *p, *siguiente, *anterior;
    int bandera, cantElim=0;
    while(act && act->ant)
    {
        act = act->ant;
    }
    while(act)
    {
        aux = act->sig;
        while(aux)
        {
            bandera = 0;
            if(aux && comparar(&act->info, &aux->info)==0)
            {
                bandera = 1;
                if(aux == *p)
                {
                    if(aux->sig)
                        *p = aux->sig;
                    else if(aux->ant)
                        *p = aux->ant;
                    else
                        *p = NULL;
                }
                anterior = aux->ant;
                siguiente = aux->sig;
                free(aux);
                aux = siguiente;
                if(anterior)
                    anterior->sig = siguiente;
                if(siguiente)
                    siguiente->ant = anterior;
                cantElim++;
            }
            else
                aux = aux->sig;
        }
        if(bandera == 1)
        {
            if(act == *p)
                {
                    if(act->sig)
                        *p = act->sig;
                    else if(act->ant)
                        *p = act->ant;
                    else
                        *p = NULL;
                }
            anterior = act->ant;
            siguiente = act->sig;
            free(act);
            act = siguiente;
            if(anterior)
                anterior->sig = siguiente;
            if(siguiente)
                siguiente->ant = anterior;
            cantElim++;
        }
        else
            act = act->sig;
    }
    return cantElim;
}

int insertarAlFinal(t_lista *p, const t_info *d)
{
    t_nodo *aux = *p, *nue;
    while(aux && aux->sig)
    {
        aux = aux->sig;
    }
    nue = (t_nodo *)malloc(sizeof(t_nodo));
    if(nue == NULL)
        return 0;
    nue->info = *d;
    nue->sig = NULL;
    nue->ant = aux;
    if(aux)
        aux->sig = nue;
    *p = nue;
    return 1;
}

int insertarAlPrincipio(t_lista *p, const t_info *d)
{
    t_nodo *nue, *aux = *p;
    if(aux)
    {
        while(aux->ant)
            aux  = aux->ant;
    }
    nue = (t_nodo *)malloc(sizeof(t_nodo));
    if(nue == NULL)
        return 0;
    nue->info = *d;
    nue->ant = NULL;
    nue->sig = aux;
    if(aux)
        aux->ant = nue;
    *p = nue;
    return 1;
}

int eliminarUnicos(t_lista *p)
{
    t_nodo *act = *p, *inicio, *aux, *anterior, *siguiente;
    int cantElim=0;
    while(act && act->ant)
        act = act->ant;
    inicio = act;
    while(act)
    {
        aux = inicio;
        while((aux && comparar(&act->info, &aux->info)!= 0) || (aux ==  act))
        {
            aux = aux->sig;
        }
        if(aux)
            act = act->sig;
        else
        {
            anterior = act->ant;
            siguiente = act->sig;
            if(act == *p)
            {
                if(act->sig)
                    *p = act->sig;
                else if(act->ant)
                    *p = act->ant;
                else
                    *p = NULL;
            }
            if(anterior)
                anterior->sig = siguiente;
            if(siguiente)
                siguiente->ant = anterior;
            cantElim++;
            free(act);
            act = siguiente;
        }
    }
    return cantElim;
}
