#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int clave ;
}t_info;

typedef struct s_nodo
{
    struct s_nodo *ant;
    t_info info;
    struct s_nodo *sig;
}t_nodo;

typedef t_nodo * t_lista;

void crearlista(t_lista *lista);
int InsertarListaDoble(t_lista *lista, t_info *info);
int comparar(t_info *, t_info *);
void pisar(t_info *, t_info *);
int ListaLlena(t_lista *lista);
int Ingresar(t_info *info);
void Mostrar(t_info *info);
int SacarDeLista(t_lista *lista , t_info *info);
int VaciarLista(t_lista *lista);
void OrdenarLista(t_lista *lista);
int ListaVacia(t_lista *lista);
int eliminarDuplicados(t_lista *p);
int insertarAlFinal(t_lista *p, const t_info *d);
int insertarAlPrincipio(t_lista *p, const t_info *d);
int eliminarUnicos(t_lista *);
