#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int num;
}t_info;

typedef struct s_nodo
{
    t_info info;
    struct s_nodo *sig;
}t_nodo;

typedef t_nodo* t_pila;


int cargarInfo(t_info *info);

void crearpila(t_pila *);
int pilavacia(const t_pila *pila);
int pilallena(const t_pila *pila);
int apilar(t_pila *pila, const t_info *info);
int desapilar(t_pila *pila, t_info *info);
void vaciarpila(t_pila *pila);
int vertope(const t_pila *, t_info *);
