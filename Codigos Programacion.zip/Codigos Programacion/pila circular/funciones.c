#include "funciones.h"

void crearpila(t_pila *p)
{
    *p = NULL;
}

int pilallena(const t_pila *p)
{
    void *aux = malloc(sizeof(t_nodo));
    free(aux);
    return aux==NULL;
}

int pilavacia(const t_pila *p)
{
    return *p == NULL;
}


int vertope(const t_pila *p, t_info *d)
{
    if(*p == NULL)
        return 0;
    *d = (*p)->sig->info;
    return 1;
}

void vaciarpila(t_pila *p)
{
    t_nodo *aux;
    while(*p)
    {
        aux = (*p)->sig;
        if(aux == *p)
            *p = NULL;
        else
            (*p)->sig = aux->sig;
        free(aux);

    }
}

int desapilar(t_pila *p, t_info *d)
{
    t_nodo *aux;
    if(*p == NULL)
        return 0;
    *d = (*p)->sig->info;
    aux = (*p)->sig;
    if(aux == *p)
        *p = NULL;
    else
        (*p)->sig = aux->sig;
    free(aux);
    return 1;
}

int apilar(t_pila *p, const t_info *d)
{
    t_nodo *nue  = (t_nodo *)sizeof(t_nodo);
    if(nue==NULL)
        return 0;
    nue->info = *d;
    if(*p == NULL)
    {
        nue->sig = nue;
        *p = nue;
    }
    else
    {
        nue->sig = (*p)->sig;
        (*p)->sig = nue;
    }
    return 1;
}
