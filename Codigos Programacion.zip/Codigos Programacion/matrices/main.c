#include "funciones.h"

int main()
{
    /*int vec[COL] = {1, 2, 3};
    int vec2[FIL];
    int mat[FIL][COL]={{2, 2, 1},{1, 5, 1},{5, 11, 32}};
    printf("la suma de los elementos de vec es : %d\n ", SumarElementos(vec, COL)); // suma los elementos de cada fila de la matriz y los guarda en un vector
    SumarElemFilas(mat, vec2);
    MostrarVector(vec2);

    int mat1[FIL][CO_FI]={{2, 3},{1, 5},{6, 6}};
    int mat2[CO_FI][COL]={{5, 3},{4, 1}};
    int matRes[FIL][COL]={{0}};
    MultiplicarMatrices(mat1, mat2, matRes);
    MostrarMatriz(&matRes[0][0], 3, 2);

    */
    int mat[FIL][COL] = {{1, 2, 3, 11, 69},{4, 5, 6, 23, 42},{7, 8, 9, 0, 3},{10, 11, 12, 13, 99},{22,23, 23, 25, 1}};
    MostrarMatriz(&mat[0][0], FIL, COL);
    PermutarCentro(mat, FIL, COL);
    MostrarMatriz(&mat[0][0], FIL, COL);



    return 0;
}
