#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define FIL 5
#define COL 5
#define CO_FI 2

int SumarElementos(int *vec, int col);
void SumarElemFilas(int mat[][COL], int *vec2);
void MostrarVector(int *vec);
void MultiplicarMatrices(int mat1[][CO_FI], int mat2[][COL], int matRes[][COL]);
void MostrarMatriz(int *, int, int);
void Permutar(int mat[][COL], int fil, int col);
void PermutarCentro(int mat[][COL], int, int);
