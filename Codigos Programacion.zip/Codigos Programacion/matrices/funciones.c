#include "funciones.h"

int SumarElementos(int *vec, int col)
{
    int cant=0;
    while(col)
    {
        cant+= *vec;
        vec++;
        col--;
    }
    return cant;
}

void SumarElemFilas(int mat[][COL], int *vec2)
{
    int i;
    for(i=0; i<FIL; i++)
    {
        *vec2 = SumarElementos(&mat[i][0], COL);
        vec2++;
    }

}
void MostrarVector(int *vec)
{
    int i;
    for(i=0; i< FIL; i++)
    {
        printf("Vector[%d]= %d \t",i , *vec);
        vec++;
    }
    printf("\n");
}


void MultiplicarMatrices(int mat1[][CO_FI], int mat2[][COL], int matRes[][COL])
{
    int ciclo, i, j;
    for(i=0; i<FIL; i++)
    {
        for(j=0; j<COL; j++)
        {
            for(ciclo=0; ciclo<CO_FI; ciclo++)
            {
                matRes[i][j]+= mat1[i][ciclo]*mat2[ciclo][j];
            }
        }
    }
}


void MostrarMatriz(int *mat, int fil, int col)
{
    int i,j;
    for(i=0; i<fil; i++)
    {
        printf("\n");
        for(j=0;j<col;j++)
        {
            printf("mat[%d][%d] = %d \t", i, j, *mat);
            mat++;
        }
    }
    printf("\n");

}

void Permutar(int mat[][COL], int fil, int col)
{
    int i, j, aux;
    for(i=0; i<fil/2; i++)
    {
        for(j=0; j<col; j++)
        {
            aux = mat[i][j];
            mat[i][j] = mat[fil-i-1][j];
            mat[fil-i-1][j] = aux;
        }
    }
}

///Trasponer una matriz respecto del centro

void PermutarCentro(int mat[][COL], int fil, int col)
{
    int i, j, aux, var;
    if(fil%2 == 0)
        var = fil/2;
    else
        var = (fil/2)+1;
    for(i = 0; i<var; i++)
    {
        for(j=0; j<col; j++)
        {
            if(i == var-1 && j == col/2)
            return;
            aux = mat[i][j];
            mat[i][j] = mat[fil-1-i][col-1-j];
            mat[fil-1-i][col-1-j] = aux;
        }
    }
}

///Trasponer una matriz respecto del centro sin el uso de un condicional

int trasponer( int m[][COL], int filas, int colum ){

    int aux;
    int     fi,
            co,
            fi2,
            co2;

	for( fi = 0, fi2 = filas-1 ; fi < filas/2 ; fi++, fi2-- ){

		for( co = 0, co2 = colum-1 ; co < colum ; co++, co2--) {

            aux = m[fi][co];
            m[fi][co] = m[fi2][co2];
            m[fi2][co2] = aux;
		}

		if( fi == fi2 )
            for( co = 0, co2 = colum-1 ; co < colum/2 ; co++, co2-- ){

                aux = m[fi][co];
                m[fi][co] = m[fi][co2];
                m[fi][co2] = aux;
            }
	}
}

///Trasponer simetricamente respecto de la contra diagonal sin condicional

int trasponer( int m[][COL], int filas, int colum ){

    int coAux = COLUM -1;
    int     fi,
            co,
            fi2,
            co2;

	for( fi = 0, co2 = COLUM-1 ; fi < filas-1 ; fi++, co2-- ){

		for( co = 0, co2 = FILAS-1 ; co < coAux ; co++, fi2--) {

            aux = m[fi][co];
            m[fi][co] = m[fi2][co2];
            m[fi2][co2] = aux;
		}

		coAux--;
    }
}

///Dividir la suma de los elementos sobre la contra diagonal por la suma de la contradiagonal. (final)

int trasponer( int m[][COL], int filas, int colum, float * cociente ){

    int     fi,
            co,
            sumContraDiagonal = 0;

    *cociente = 0.0;

	for( fi = 0 ; fi < filas-1 ; fi++ ){

		for( co = 0 ; co < COLUM-fi-1 ; co++ )
            *cociente += m[fi][co];

        sumContraDiagonal += m[fi][co];
	}

    if( sumContraDiagonal )
        *cociente /= sumContraDiagonal;

    return sumContraDiagonal != 0;
}





