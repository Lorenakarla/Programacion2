#include "funciones.h"

int main()
{
    int i;
    t_dias dias[7];
    for(i=0; i<7; i++)
    {
        printf("ingrese el dia: ");
        scanf("%s", dias[i].dia);
    }
    for(i=0; i<7; i++)
        printf("los dias son: %s\n", dias[i].dia);
    return 0;
}
