#include <stdio.h>
#include <stdlib.h>
#define TAM 10

typedef struct
{
    char dia[TAM];
}t_dias;
