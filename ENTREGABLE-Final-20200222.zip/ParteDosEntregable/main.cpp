
#include "main.h"


int main()
{
    Cuenta cuenta1,
           cuenta2( "Juan Fernandez Rubio", "12345678901234567890", 1.75, 300);

    cin >> cuenta1;
    Cuenta cuenta3(cuenta1);
    cout << "\n >>>>>> Datos de la cuenta 1 <<<<<<<" <<endl;
    cout << cuenta1;
    cuenta1.ingreso(4000);
    cuenta1.mostrarSaldo();
    cout << "\n >>>>>> Datos de la cuenta 2 <<<<<<<" <<endl;
    cout << cuenta2;
    cout << "\n >>>>>> Datos de la cuenta 3 <<<<<<<" <<endl;
    cout << cuenta3;
    if ( cuenta3.transferencia(cuenta2, 100) == true)
        cout << "Transferencia exitosa" <<endl;

    cout << "\n >>>>>> Saldo de la cuenta 2 <<<<<<<" <<endl;
    cuenta2.mostrarSaldo();
    cout << "\n >>>>>> Saldo de la cuenta 3 <<<<<<<" <<endl;
    cuenta3.mostrarSaldo();
    return 0;
}
