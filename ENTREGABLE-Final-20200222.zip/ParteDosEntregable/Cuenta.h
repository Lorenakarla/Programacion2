#ifndef CUENTA_H_INCLUDED
#define CUENTA_H_INCLUDED





class Cuenta
{

    private:
        char *nombre;
        char *nroCuenta;
        double tipoInteres;
        double saldo;
/** complete la declaraci�n de la class **/


#endif
