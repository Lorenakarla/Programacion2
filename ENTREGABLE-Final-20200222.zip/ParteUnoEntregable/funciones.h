#ifndef FUNCIONES_H_
#define FUNCIONES_H_

#include <string.h>
#include <stdlib.h>
#include <stdio.h>




char *trozar(char *s, const char *b);

char *ultimaSubCad(const char *cad, const char *bus);

#define SIN_MEM     2
#define CLA_DUP     1
#define TODO_BIEN   0

typedef struct
{
    int     di,
            me,
            an;
} tFecha;

typedef struct
{
    char apyn[36];
    char sex;
    tFecha  fecNac;
} tPersona;

typedef tPersona tInfo;

typedef struct sNodo
{
    tInfo   info;
    struct sNodo   *izq,
                   *der;
} tNodo, *tListaD, *tArbolB;



void crearListaD(tListaD *p);

int ingresarPersona(tPersona *d);

void mostrarPersona(const tPersona *d);

int compPersXApyn(const tPersona *d1, const tPersona *d2);

int compPersXMesDiaSex1erNombre(const tPersona *d1, const tPersona *d2);

int compPersX1erNom(const tPersona *d1, const tPersona *d2);

void reemplazarPers(tPersona *d1, const tPersona *d2);

int insertarEnOrdenLD(tListaD *p, const tInfo *d,
                      int (*comp)(const tInfo *, const tInfo *),
                      void (*acum)(tInfo *, const tInfo *),
                      void (*mostrar)(const tInfo *));

int mostrarLista(const tListaD *p, void (*mostrar)(const tInfo *));

int eliminarDuplicados(tListaD *p,
                       int (*comp)(const tPersona *, const tPersona *),
                       void (*mostrar)(const tPersona *));

/** declare, quitando los comentarios, su propia versi�n de: **/

/// Punto 1.a.-
/**
char *trozar_MIO(char *s, const char *b);
 **/

/// Punto 1.b.-
/**
char *ultimaSubCad_MIO(const char *cad, const char *bus);
 **/

/// Punto 2.a.-
/**
int compPersXMesDiaSex1erNombre_MIO(const tPersona *d1, const tPersona *d2);

int insertarEnOrdenLD_MIO(tListaD *p, const tInfo *d,
                          int (comp)(const tInfo *, const tInfo *),
                          void (*acum)(tInfo *, const tInfo *),
                          void (*mostrar)(const tInfo *));
 **/

/// Punto 2.b.-
/**
int compPersX1erNom_MIO(const tPersona *d1, const tPersona *d2);

int eliminarDuplicados_MIO(tListaD *p,
                           int (*comp)(const tPersona *, const tPersona *),
                           void (*mostrar)(const tPersona *));
 **/

#endif
