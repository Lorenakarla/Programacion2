
#include "funciones.h"





/** desarrolle su propia versi�n de: **/

/// Punto 1.a.-
/**
char *trozar_MIO(char *s, const char *b)
{

}
 **/

/// Punto 1.b.-
/**
char *ultimaSubCad_MIO(const char *cad, const char *bus)
{

}
 **/

/// Punto 2.a.-
/**
int compPersXMesDiaSex1erNombre_MIO(const tPersona *d1, const tPersona *d2)
{

}

int insertarEnOrdenLD_MIO(tListaD *p, const tInfo *d,
                          int (comp)(const tInfo *, const tInfo *),
                          void (*acum)(tInfo *, const tInfo *),
                          void (*mostrar)(const tInfo *))
{

}
 **/

/// Punto 2.b.-
/**
int compPersX1erNom_MIO(const tPersona *d1, const tPersona *d2)
{

}

int eliminarDuplicados_MIO(tListaD *p,
                           int (*comp)(const tPersona *, const tPersona *),
                           void (*mostrar)(const tPersona *))
{

}
 **/

