
#include "main.h"


int main()
{
    punto1A();

    punto1B();

    punto2A();

    punto2B();

    return 0;
}

void punto1A(void)
{
    char    texto[30],
            subCad[] = { "\t@ |$*" },
            subCad2[] = { "!#%%^&" },
            subCad3[] = { "" },
           *aux;
    int     veces;

    printf("Punto 1.a.-\n");
    veces = 0;
    strcpy(texto, "Es \t  la\t|*hora\t\tde||*salir");
    printf("Prueba con\nTexto:  \"%s\"\nSubCad: \"%s\"\n\n", texto, subCad);
/// while(( aux = trozar_MIO(texto, subCad) ) != NULL)
    while(( aux = trozar(texto, subCad) ) != NULL)
    {
        printf("Texto queda:  \"%s\"\nEncontrado: \"%s\"\n", texto, aux);
        veces++;
    }
    printf("%sVeces: %d\n\n", veces == 0 ? "No encontrado\n" : "", veces);
    veces = 0;
    strcpy(texto, "Es \t  la\t|*hora\t\tde||*salir");
    printf("Prueba con\nTexto:  \"%s\"\nSubCad: \"%s\"\n\n", texto, subCad2);
/// while(( aux = trozar_MIO(texto, subCad2) ) != NULL)
    while(( aux = trozar(texto, subCad2) ) != NULL)
    {
        printf("Texto queda:  \"%s\"\nEncontrado: \"%s\"\n", texto, aux);
        veces++;
    }
    printf("%sVeces: %d\n\n", veces == 0 ? "No encontrado\n" : "", veces);
    veces = 0;
    strcpy(texto, "Es \t  la\t|*hora\t\tde||*salir");
    printf("Prueba con\nTexto:  \"%s\"\nSubCad: \"%s\"\n\n", texto, subCad3);
/// while(( aux = trozar_MIO(texto, subCad3) ) != NULL)
    while(( aux = trozar(texto, subCad3) ) != NULL)
    {
        printf("Texto queda:  \"%s\"\nEncontrado: \"%s\"\n", texto, aux);
        veces++;
    }
    printf("%sVeces: %d\n\n", veces == 0 ? "No encontrado\n" : "", veces);
    puts("/* --------o---x---o-------- */");
}

void punto1B(void)
{
    char    texto[] = { "DALO POR HECHO. Es hora de darlo por terminado" },
            subCad[] = { "Lo Por" },
            subCad2[] = { "" },
            subCad3[] = { "Pepe" },
           *aux;

    printf("Punto 1.b.-\n");
/// aux = ultimaSubCad_MIO(texto, subCad);
    aux = ultimaSubCad(texto, subCad);
    printf("Prueba con\nTexto:  \"%s\"\nSubCad: \"%s\"\nEncontrado: \"%s\"\n\n",
           texto, subCad, aux ? aux : "***NO ENCONTRADO***");
/// aux = ultimaSubCad_MIO(texto, subCad2);
    aux = ultimaSubCad(texto, subCad2);
    printf("Prueba con\nTexto:  \"%s\"\nSubCad: \"%s\"\nEncontrado: \"%s\"\n\n",
           texto, subCad2, aux ? aux : "***NO ENCONTRADO***");
/// aux = ultimaSubCad_MIO(texto, subCad3);
    aux = ultimaSubCad(texto, subCad3);
    printf("Prueba con\nTexto:  \"%s\"\nSubCad: \"%s\"\nEncontrado: \"%s\"\n\n",
           texto, subCad3, aux ? aux : "***NO ENCONTRADO***");
    puts("/* --------o---x---o-------- */");
}

void punto2A(void)
{
    tListaD     lista;
    tPersona    pers;
    int         cant = 0,
                dupl = 0,
                res = TODO_BIEN;

    printf("Punto 2.a.-\n");
    crearListaD(&lista);
    while(res != SIN_MEM && ingresarPersona(&pers))
    {
        int res = insertarEnOrdenLD(&lista, &pers,
                                    compPersXMesDiaSex1erNombre,
                                    reemplazarPers, mostrarPersona);
///     int res = insertarEnOrdenLD_MIO(&lista, &pers,
///                                     compPersXMesDiaSex1erNombre_MIO,
///                                     reemplazarPers, mostrarPersona);
        if(res == TODO_BIEN)
            cant++;
        else
            if(res == CLA_DUP)
                dupl++;
    }
    printf("Se pusieron %d nodos en la lista\n"
           "Se reemplazaron %d por clave duplicada (mes-dia-sexo-1er Nom)\n"
           "%subo error por falta de memoria\n",
           cant, dupl, res == SIN_MEM ? "H" : "No h");
    puts("Mostrando la lista:");
    cant = mostrarLista(&lista, mostrarPersona);
    printf("Se mostraron %d nodos\n", cant);
    puts("/* --------o---x---o-------- */");
}

void punto2B(void)
{
    tListaD     lista;
    tPersona    pers;
    int         cant = 0,
                dupl = 0,
                res = TODO_BIEN;

    printf("Punto 2.b.-\n");
    crearListaD(&lista);
    while(res != SIN_MEM && ingresarPersona(&pers))
    {
        int res = insertarEnOrdenLD(&lista, &pers,
                                    compPersXApyn,
                                    reemplazarPers,
                                    mostrarPersona);
        if(res == TODO_BIEN)
            cant++;
        else
            if(res == CLA_DUP)
                dupl++;
    }
    printf("Se pusieron %d nodos en la lista\n"
           "Se reemplazaron %d por clave duplicada (Apellido y Nombre)\n"
           "%subo error por falta de memoria\n",
           cant, dupl, res == SIN_MEM ? "H" : "No h");
    puts("Mostrando la lista:");
    cant = mostrarLista(&lista, mostrarPersona);
    printf("Se mostraron %d nodos\n", cant);
    puts("Eliminando nodos con el primer nombre repetido.");
    cant = eliminarDuplicados(&lista, compPersX1erNom, mostrarPersona);
/// cant = eliminarDuplicados_MIO(&lista, compPersX1erNom_MIO, mostrarPersona);
    printf("Se eliminaron %d nodos\n", cant);
    cant = mostrarLista(&lista, mostrarPersona);
    printf("Quedaron %d nodos\n", cant);
    puts("/* --------o---x---o-------- */");
}

