#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>


#include "funciones.h"


void punto1A(void);

void punto1B(void);

void punto2A(void);

void punto2B(void);



#endif
