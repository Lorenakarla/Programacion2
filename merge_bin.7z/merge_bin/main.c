#include "main.h"

int main()
{
    FILE *pf_alu=NULL;
    FILE *pf_emp=NULL;
    t_empleado empleado;
    t_alumno alumno;

    printf("----------------------------------\n");
    printf("\tArchivo de Alumnos\n");
    printf("----------------------------------\n");
    generar_lote_alu();
    printf("\n");
    printf("\n");
    printf("----------------------------------\n");
    printf("\tArchivo de Empleados\n");
    printf("----------------------------------\n");
    generar_lote_empleado();

    if(!abrir_archivo(&pf_alu,"alumnos.dat","rb",0) )
    {
        return 1;
    }

    if(!abrir_archivo(&pf_emp,"trabajador.dat","rb+",0))
    {
        fclose(pf_alu);
        fclose(pf_emp);
        return 2;
    }
    rewind(pf_alu);
    rewind(pf_emp);
    printf("\nEmpieza la logica\n");
    fread(&alumno,sizeof(t_alumno),1,pf_alu);
    fread(&empleado,sizeof(t_empleado),1,pf_emp);


    while(!feof(pf_alu) || !feof(pf_emp))
    {
        /**dni1 >> dni2*/
        if( (comparar_x_dni(&alumno.dni,&empleado.dni)) > 0)
        {
            fread(&empleado,sizeof(t_empleado),1,pf_emp);
        }

        /**dni1 << dni2*/
        else if( (comparar_x_dni(&alumno.dni,&empleado.dni)) < 0)
        {
            fread(&alumno,sizeof(t_alumno),1,pf_alu);
        }

        /**dni1 == dni2*/
        else if((comparar_x_dni(&alumno.dni,&empleado.dni))==0)
        {
            if(alumno.promedio > 7)
            {
                /**me posiciono al principio del archivo*/
                fseek(pf_emp,-sizeof(t_empleado),SEEK_CUR);
                actualizar_empleados(&empleado);
                /**grabo en el archivo correspondiente*/
                fwrite(&empleado, sizeof(t_empleado),1,pf_emp);
                /**grabo-leo el mismo archivo entonces: */
                fseek(pf_emp,0L,SEEK_CUR);
            }

            fread(&alumno,sizeof(t_alumno),1,pf_alu);
            fread(&empleado,sizeof(t_empleado),1,pf_emp);
        }
    }

    while(!feof(pf_alu))
        fread(&alumno,sizeof(t_alumno),1,pf_alu);

    while(!feof(pf_emp))
        fread(&empleado,sizeof(t_empleado),1,pf_emp);

    fclose(pf_alu);
    fclose(pf_emp);

    printf("----------------------------------\n");
    printf("\tArchivo de Alumnos\n");
    printf("----------------------------------\n");

    if(!abrir_archivo(&pf_alu,"alumnos.dat","rb",0))
        printf("\nError abriendo el archivo 1\n");
    fread(&alumno,sizeof(t_alumno),1,pf_alu);

    while(!feof(pf_alu))
    {
        printf("%d %s %.2f\n", alumno.dni,alumno.apyn,alumno.promedio);
        fread(&alumno,sizeof(t_alumno),1,pf_alu);
    }

    if(!abrir_archivo(&pf_emp,"trabajador.dat","rb",0))
        printf("\nError abriendo el archivo 2\n");

    printf("\n");
    printf("----------------------------------\n");
    printf("Archivo de Empleados Actualizado\n");
    printf("----------------------------------\n");

    fread(&empleado,sizeof(t_empleado),1,pf_emp);

    while(!feof(pf_emp))
    {
        printf("%d %s %.2f\n", empleado.dni,empleado.apyn,empleado.sueldo);
        fread(&empleado,sizeof(t_empleado),1,pf_emp);
    }

    fclose(pf_alu);
    fclose(pf_emp);

    return 0;
}
