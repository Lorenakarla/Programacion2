#ifndef EMPLEADOS_H_INCLUDED
#define EMPLEADOS_H_INCLUDED
#include "main.h"


typedef struct
{
    int dni;
    char apyn[30];
    double sueldo;
}t_empleado;

void generar_lote_empleado();
void actualizar_empleados(t_empleado *e);

#endif // EMPLEADOS_H_INCLUDED
