#ifndef ALUMNOS_H_INCLUDED
#define ALUMNOS_H_INCLUDED

#include "main.h"

typedef struct
{
    int dni;
    char apyn[30];
    float promedio;
}t_alumno;

void generar_lote_alu();
int comparar_x_dni(const void *d1, const void *d2);

#endif // ALUMNOS_H_INCLUDED
