#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "empleados.h"
#include "alumnos.h"

int abrir_archivo(FILE **pf, const char *nombre, const char *modo, int msj);




#endif // MAIN_H_INCLUDED
