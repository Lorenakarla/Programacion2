#include "alumnos.h"
#include "main.h"

void generar_lote_alu(){

    t_alumno alumno;
    t_alumno alu[]=
    {
        {12334566,"Rodrigo Rodriguez",9.9},
        {12234567,"Gisela Gil",9.99},
        {12345678,"Martin Martinez", 8.99},
        {12334679,"Ramiro Ramirez", 7.83}
    };

    FILE *pf;

    if( !(pf=fopen("alumnos.dat","wb")))
    {
        printf("\nError al crear el archivo de alumnos\n");
        return;
    }

    fwrite(&alu,sizeof(alu),1,pf);

    fclose(pf);

    /*COMPRUEBO QUE FUE CREADO, LEYENDOLO*/
    if( !(pf=fopen("alumnos.dat","rb")))
    {
        printf("\nError abriendo el archivo de alumnos\n");
        return;
    }

    fread(&alumno,sizeof(t_alumno),1,pf);

    while(!feof(pf))
    {
        printf("%d %s %.2f\n", alumno.dni,alumno.apyn,alumno.promedio);
        fread(&alumno,sizeof(t_alumno),1,pf);
    }

    /**cierro el archivo*/
    fclose(pf);
}

int comparar_x_dni(const void *d1, const void *d2)
{
    t_alumno *a1 = (t_alumno *)d1;
    t_alumno *a2 = (t_alumno *)d2;
    int cmp=a1->dni - a2->dni ;

    return cmp;
}
