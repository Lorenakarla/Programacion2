#include "main.h"
#include "empleados.h"

int abrir_archivo(FILE **pf, const char *nombre, const char *modo, int msj)
{
    *pf=fopen(nombre,modo);

    if(!pf)
    {
        printf("Error al abrir el archivo %s en %s", nombre, modo);
        return 0;
    }
    else
    {
        if(msj)
        {
            printf("\nEl archivo esta ok\n");
        }

    }

    return 1;
}
void generar_lote_empleado()
{
    t_empleado esclavo[]=
    {
        {12334566,"Rodrigo Rodriguez", 29350},
        {12234567,"Gisela Gil",23568},
        {12345678,"Martin Martinez", 18250},
        {12334679,"Ramiro Ramirez", 30478}

    };
    FILE *pf;
    t_empleado emp;

    if( !(pf=fopen("trabajador.dat","wb")))
    {
        printf("\nError al crear el archivo de empleados\n");
        return;
    }

    fwrite(esclavo,sizeof(esclavo),1,pf);

    fclose(pf);
    //////////////////////////////////////////////

      if( !(pf=fopen("trabajador.dat","rb")))
    {
        printf("\nError al leer el archivo de empleados\n");
        return;
    }

    fread(&emp,sizeof(t_empleado),1,pf);

    while(!feof(pf))
    {
        printf("%d %s %.2f\n", emp.dni,emp.apyn,emp.sueldo);
        fread(&emp,sizeof(t_empleado),1,pf);
    }

    /**cierro el archivo*/
    fclose(pf);
}

void actualizar_empleados(t_empleado *e)
{
    e->sueldo*=1.28;
}
